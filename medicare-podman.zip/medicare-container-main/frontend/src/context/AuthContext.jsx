import { createContext, useContext, useState, useCallback, useMemo } from 'react';
import client from '../api/client';
import { authApi } from '../api/endpoints';

const AuthContext = createContext(null);

function loadStoredUser() {
  try {
    const raw = localStorage.getItem('medicare_user');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(loadStoredUser());
  const [loading, setLoading] = useState(false);

  const persist = useCallback((token, userData) => {
    localStorage.setItem('medicare_token', token);
    localStorage.setItem('medicare_user', JSON.stringify(userData));
    setUser(userData);
  }, []);

  const login = useCallback(async (email, password) => {
    setLoading(true);
    try {
      const { data } = await authApi.loginJson({ email, password });
      const userData = { id: data.user_id, name: data.name, role: data.role };
      persist(data.access_token, userData);
      return userData;
    } finally {
      setLoading(false);
    }
  }, [persist]);

  const register = useCallback(async (payload) => {
    setLoading(true);
    try {
      const { data } = await authApi.register(payload);
      const userData = { id: data.user_id, name: data.name, role: data.role };
      persist(data.access_token, userData);
      return userData;
    } finally {
      setLoading(false);
    }
  }, [persist]);

  const logout = useCallback(() => {
    localStorage.removeItem('medicare_token');
    localStorage.removeItem('medicare_user');
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, register, logout, isAuthenticated: !!user }),
    [user, loading, login, register, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export { client };
