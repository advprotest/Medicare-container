import { useEffect, useState } from 'react';
import { usersApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';

const ROLE_OPTIONS = ['', 'patient', 'doctor', 'nurse', 'receptionist', 'lab_technician', 'pharmacist', 'admin'];

export default function Users() {
  const [users, setUsers] = useState([]);
  const [role, setRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const { data } = await usersApi.list(role || undefined);
      setUsers(data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [role]);

  async function toggleActive(u) {
    setBusyId(u.id);
    setError('');
    try {
      if (u.is_active) await usersApi.deactivate(u.id);
      else await usersApi.activate(u.id);
      await load();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Administration</span>
          <h1>Users</h1>
          <p>Manage access across every role in the hospital.</p>
        </div>
      </div>

      <select value={role} onChange={(e) => setRole(e.target.value)} style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)', marginBottom: 20 }}>
        {ROLE_OPTIONS.map((r) => <option key={r} value={r}>{r ? r.replace(/_/g, ' ') : 'All roles'}</option>)}
      </select>

      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading ? <Loading /> : users.length === 0 ? (
        <EmptyState title="No users found" />
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td style={{ textTransform: 'capitalize' }}>{u.role.replace(/_/g, ' ')}</td>
                  <td><StatusBadge status={u.is_active ? 'active' : 'inactive'} /></td>
                  <td>
                    <button
                      className={`btn btn--sm ${u.is_active ? 'btn--danger' : 'btn--primary'}`}
                      disabled={busyId === u.id}
                      onClick={() => toggleActive(u)}
                    >
                      {u.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
