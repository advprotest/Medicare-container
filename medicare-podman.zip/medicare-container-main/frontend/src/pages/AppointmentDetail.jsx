import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { appointmentsApi, labTestsApi, prescriptionsApi, billingApi, pharmacyApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, ErrorBanner } from '../components/Feedback';
import Pathway from '../components/Pathway';
import StatusBadge from '../components/StatusBadge';
import { useAuth } from '../context/AuthContext';

export default function AppointmentDetail() {
  const { appointmentId } = useParams();
  const { user } = useAuth();
  const [appt, setAppt] = useState(null);
  const [labTests, setLabTests] = useState([]);
  const [prescription, setPrescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const canDoctor = ['doctor', 'admin'].includes(user.role);
  const canStaff = ['receptionist', 'nurse', 'admin'].includes(user.role);
  const canBilling = ['receptionist', 'admin'].includes(user.role);

  async function loadAll() {
    setLoading(true);
    setError('');
    try {
      const { data } = await appointmentsApi.get(appointmentId);
      setAppt(data);
      const { data: tests } = await labTestsApi.forAppointment(appointmentId);
      setLabTests(tests);
      try {
        const { data: rx } = await prescriptionsApi.forAppointment(appointmentId);
        setPrescription(rx);
      } catch {
        setPrescription(null);
      }
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadAll(); /* eslint-disable-next-line */ }, [appointmentId]);

  if (loading) return <Loading />;
  if (!appt) return <ErrorBanner message={error || 'Appointment not found.'} />;

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Appointment</span>
          <h1>{appt.slot_date} at {appt.slot_time}</h1>
          <p>{appt.reason || 'No reason provided at booking.'}</p>
        </div>
        <StatusBadge status={appt.status} />
      </div>

      <ErrorBanner message={error} onDismiss={() => setError('')} />
      {success && <div className="success-banner">{success}</div>}

      <div className="card" style={{ marginBottom: 20 }}>
        <Pathway status={appt.status} />
      </div>

      {canStaff && <StaffActions appt={appt} onUpdated={loadAll} setError={setError} setSuccess={setSuccess} />}

      {canDoctor && ['booked', 'checked_in'].includes(appt.status) && (
        <ReschedulePanel appt={appt} onUpdated={loadAll} setError={setError} setSuccess={setSuccess} />
      )}

      {canDoctor && (
        <ConsultationPanel appt={appt} onUpdated={loadAll} setError={setError} setSuccess={setSuccess} />
      )}

      <div className="grid grid-cols-2 spacer-top">
        <LabTestsPanel
          appointmentId={appointmentId}
          tests={labTests}
          canOrder={canDoctor}
          onChanged={loadAll}
          setError={setError}
          setSuccess={setSuccess}
        />
        <PrescriptionPanel
          appointmentId={appointmentId}
          prescription={prescription}
          canCreate={canDoctor}
          onChanged={loadAll}
          setError={setError}
          setSuccess={setSuccess}
        />
      </div>

      {canBilling && (
        <div className="spacer-top">
          <BillingPanel appointmentId={appointmentId} setError={setError} setSuccess={setSuccess} />
        </div>
      )}
    </div>
  );
}

function StaffActions({ appt, onUpdated, setError, setSuccess }) {
  const [busy, setBusy] = useState(false);
  const nextMap = { booked: 'checked_in', checked_in: 'in_consultation', in_consultation: 'completed' };
  const next = nextMap[appt.status];

  async function advance() {
    setBusy(true);
    setError('');
    try {
      await appointmentsApi.updateStatus(appt.id, next);
      setSuccess(`Status updated to "${next.replace(/_/g, ' ')}".`);
      onUpdated();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function cancel() {
    setBusy(true);
    setError('');
    try {
      await appointmentsApi.updateStatus(appt.id, 'cancelled');
      setSuccess('Appointment cancelled.');
      onUpdated();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  if (!next && !['booked', 'checked_in'].includes(appt.status)) return null;

  return (
    <div className="card" style={{ marginBottom: 20 }}>
      <h3>Front desk actions</h3>
      <div className="row">
        {next && <button className="btn btn--primary" disabled={busy} onClick={advance}>Move to "{next.replace(/_/g, ' ')}"</button>}
        {['booked', 'checked_in'].includes(appt.status) && (
          <button className="btn btn--danger" disabled={busy} onClick={cancel}>Cancel appointment</button>
        )}
      </div>
    </div>
  );
}

function ReschedulePanel({ appt, onUpdated, setError, setSuccess }) {
  const [slotDate, setSlotDate] = useState(appt.slot_date);
  const [slotTime, setSlotTime] = useState(appt.slot_time);
  const [saving, setSaving] = useState(false);

  const changed = slotDate !== appt.slot_date || slotTime !== appt.slot_time;

  async function handleReschedule(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await appointmentsApi.reschedule(appt.id, { slot_date: slotDate, slot_time: slotTime });
      setSuccess(`Appointment moved to ${slotDate} at ${slotTime}.`);
      onUpdated();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="card" style={{ marginBottom: 20 }}>
      <h3>Reschedule appointment</h3>
      <form onSubmit={handleReschedule}>
        <div className="form-row">
          <div className="field">
            <label htmlFor="reschedule-date">New date</label>
            <input id="reschedule-date" type="date" required value={slotDate} onChange={(e) => setSlotDate(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="reschedule-time">New time</label>
            <input id="reschedule-time" type="time" required value={slotTime} onChange={(e) => setSlotTime(e.target.value)} />
          </div>
        </div>
        <button className="btn btn--ghost" type="submit" disabled={saving || !changed}>
          {saving ? 'Rescheduling…' : 'Save new date & time'}
        </button>
      </form>
    </div>
  );
}

function ConsultationPanel({ appt, onUpdated, setError, setSuccess }) {
  const [diagnosis, setDiagnosis] = useState(appt.diagnosis || '');
  const [notes, setNotes] = useState(appt.consultation_notes || '');
  const [saving, setSaving] = useState(false);

  const editable = ['checked_in', 'in_consultation'].includes(appt.status);

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await appointmentsApi.addConsultationNotes(appt.id, { diagnosis: diagnosis || undefined, notes });
      setSuccess('Consultation notes saved.');
      onUpdated();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="card" style={{ marginBottom: 20 }}>
      <h3>Consultation notes</h3>
      {!editable && !appt.consultation_notes && <p className="muted">Notes can be added once the patient is checked in.</p>}
      {!editable && appt.consultation_notes ? (
        <div className="stack">
          <div><strong>Diagnosis:</strong> {appt.diagnosis || '—'}</div>
          <div><strong>Notes:</strong> {appt.consultation_notes}</div>
        </div>
      ) : editable && (
        <form onSubmit={handleSave}>
          <div className="field">
            <label htmlFor="diagnosis">Diagnosis</label>
            <input id="diagnosis" value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} placeholder="Optional" />
          </div>
          <div className="field">
            <label htmlFor="notes">Notes</label>
            <textarea id="notes" required value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Consultation findings, recommendations…" />
          </div>
          <button className="btn btn--primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save notes'}</button>
        </form>
      )}
    </div>
  );
}

function LabTestsPanel({ appointmentId, tests, canOrder, onChanged, setError, setSuccess }) {
  const [testName, setTestName] = useState('');
  const [notes, setNotes] = useState('');
  const [ordering, setOrdering] = useState(false);

  async function handleOrder(e) {
    e.preventDefault();
    setOrdering(true);
    setError('');
    try {
      await labTestsApi.order({ appointment_id: appointmentId, test_name: testName, notes: notes || undefined });
      setTestName('');
      setNotes('');
      setSuccess('Lab test ordered.');
      onChanged();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setOrdering(false);
    }
  }

  return (
    <div className="card">
      <h3>Lab tests</h3>
      {tests.length === 0 ? <p className="muted">No lab tests ordered for this appointment.</p> : (
        <div className="stack" style={{ marginBottom: canOrder ? 18 : 0 }}>
          {tests.map((t) => (
            <div className="row-between" key={t.id}>
              <div>
                <div style={{ fontWeight: 600 }}>{t.test_name}</div>
                {t.result_summary && <div className="muted" style={{ fontSize: '0.82rem' }}>{t.result_summary}</div>}
              </div>
              <StatusBadge status={t.status} />
            </div>
          ))}
        </div>
      )}
      {canOrder && (
        <form onSubmit={handleOrder}>
          <div className="field">
            <label htmlFor="testName">Order a new test</label>
            <input id="testName" required value={testName} onChange={(e) => setTestName(e.target.value)} placeholder="e.g. Complete Blood Count" />
          </div>
          <div className="field">
            <label htmlFor="testNotes">Notes (optional)</label>
            <input id="testNotes" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          <button className="btn btn--ghost btn--sm" type="submit" disabled={ordering}>{ordering ? 'Ordering…' : 'Order test'}</button>
        </form>
      )}
    </div>
  );
}

function PrescriptionPanel({ appointmentId, prescription, canCreate, onChanged, setError, setSuccess }) {
  const [medicines, setMedicines] = useState([{ medicine_name: '', dosage: '', frequency: '', duration: '' }]);
  const [instructions, setInstructions] = useState('');
  const [saving, setSaving] = useState(false);
  const [inventory, setInventory] = useState([]);
  const [inventoryError, setInventoryError] = useState(false);

  useEffect(() => {
    if (!canCreate) return;
    (async () => {
      try {
        const { data } = await pharmacyApi.list();
        setInventory(data);
      } catch {
        setInventoryError(true);
      }
    })();
  }, [canCreate]);

  function updateMed(i, key, value) {
    setMedicines((m) => m.map((med, idx) => (idx === i ? { ...med, [key]: value } : med)));
  }
  function addMed() {
    setMedicines((m) => [...m, { medicine_name: '', dosage: '', frequency: '', duration: '' }]);
  }
  function removeMed(i) {
    setMedicines((m) => m.filter((_, idx) => idx !== i));
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await prescriptionsApi.create({
        appointment_id: appointmentId,
        medicines: medicines.filter((m) => m.medicine_name),
        instructions: instructions || undefined,
      });
      setSuccess('Prescription created.');
      onChanged();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="card">
      <h3>Prescription</h3>
      {prescription ? (
        <div className="stack">
          {prescription.medicines.map((m, i) => (
            <div key={i} className="pill">{m.medicine_name} · {m.dosage} · {m.frequency} · {m.duration}</div>
          ))}
          {prescription.instructions && <p className="muted">{prescription.instructions}</p>}
        </div>
      ) : canCreate ? (
        <form onSubmit={handleSave}>
          {medicines.map((m, i) => (
            <div className="form-row" key={i}>
              <div className="field">
                {inventory.length > 0 ? (
                  <select required value={m.medicine_name} onChange={(e) => updateMed(i, 'medicine_name', e.target.value)}>
                    <option value="" disabled>Select medicine…</option>
                    {inventory.map((med) => (
                      <option key={med.id} value={med.name} disabled={med.quantity_in_stock < 1}>
                        {med.name}{med.quantity_in_stock < 1 ? ' (out of stock)' : ''}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input placeholder="Medicine" required value={m.medicine_name} onChange={(e) => updateMed(i, 'medicine_name', e.target.value)} />
                )}
              </div>
              <div className="field"><input placeholder="Dosage" required value={m.dosage} onChange={(e) => updateMed(i, 'dosage', e.target.value)} /></div>
              <div className="field"><input placeholder="Frequency" required value={m.frequency} onChange={(e) => updateMed(i, 'frequency', e.target.value)} /></div>
              <div className="field"><input placeholder="Duration" required value={m.duration} onChange={(e) => updateMed(i, 'duration', e.target.value)} /></div>
              {medicines.length > 1 && <button type="button" className="icon-button" onClick={() => removeMed(i)}>×</button>}
            </div>
          ))}
          {inventoryError && <p className="muted" style={{ fontSize: '0.82rem' }}>Couldn't load the pharmacy list — type the medicine name instead.</p>}
          <button type="button" className="btn btn--ghost btn--sm" onClick={addMed} style={{ marginBottom: 12 }}>+ Add medicine</button>
          <div className="field">
            <label htmlFor="instructions">Instructions</label>
            <textarea id="instructions" value={instructions} onChange={(e) => setInstructions(e.target.value)} />
          </div>
          <button className="btn btn--primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Create prescription'}</button>
        </form>
      ) : (
        <p className="muted">No prescription issued yet.</p>
      )}
    </div>
  );
}

function BillingPanel({ appointmentId, setError, setSuccess }) {
  const [items, setItems] = useState([{ description: '', amount: '' }]);
  const [method, setMethod] = useState('offline');
  const [generating, setGenerating] = useState(false);
  const [invoice, setInvoice] = useState(null);

  function updateItem(i, key, value) {
    setItems((it) => it.map((row, idx) => (idx === i ? { ...row, [key]: value } : row)));
  }
  function addItem() { setItems((it) => [...it, { description: '', amount: '' }]); }
  function removeItem(i) { setItems((it) => it.filter((_, idx) => idx !== i)); }

  async function handleGenerate(e) {
    e.preventDefault();
    setGenerating(true);
    setError('');
    try {
      const { data } = await billingApi.generate({
        appointment_id: appointmentId,
        line_items: items.filter((it) => it.description && it.amount).map((it) => ({ description: it.description, amount: Number(it.amount) })),
        payment_method: method,
      });
      setInvoice(data);
      setSuccess(`Invoice #${data.invoice_no} generated for ₹${data.amount}.`);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="card">
      <h3>Generate bill</h3>
      {invoice ? (
        <div className="stack">
          <p>Invoice <Link to={`/billing?invoice=${invoice.invoice_no}`}>#{invoice.invoice_no}</Link> · ₹{invoice.amount} · <StatusBadge status={invoice.status} /></p>
        </div>
      ) : (
        <form onSubmit={handleGenerate}>
          {items.map((it, i) => (
            <div className="form-row" key={i}>
              <div className="field"><input placeholder="Description" required value={it.description} onChange={(e) => updateItem(i, 'description', e.target.value)} /></div>
              <div className="field"><input placeholder="Amount (₹)" type="number" min="0" step="0.01" required value={it.amount} onChange={(e) => updateItem(i, 'amount', e.target.value)} /></div>
              {items.length > 1 && <button type="button" className="icon-button" onClick={() => removeItem(i)}>×</button>}
            </div>
          ))}
          <button type="button" className="btn btn--ghost btn--sm" onClick={addItem} style={{ marginBottom: 12 }}>+ Add line item</button>
          <div className="field">
            <label htmlFor="method">Payment method</label>
            <select id="method" value={method} onChange={(e) => setMethod(e.target.value)}>
              <option value="offline">Offline</option>
              <option value="online">Online</option>
              <option value="insurance">Insurance</option>
            </select>
          </div>
          <button className="btn btn--primary" type="submit" disabled={generating}>{generating ? 'Generating…' : 'Generate invoice'}</button>
        </form>
      )}
    </div>
  );
}