import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { patientsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';

export default function Patients() {
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const { data } = await patientsApi.list();
        setPatients(data);
      } catch (err) {
        setError(apiErrorMessage(err));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = patients.filter((p) =>
    !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Directory</span>
          <h1>Patients</h1>
          <p>Search the patient roster and open a chart for history and records.</p>
        </div>
      </div>

      <input
        placeholder="Search by name or email…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)', minWidth: 280, marginBottom: 20 }}
      />

      <ErrorBanner message={error} />

      {loading ? <Loading /> : filtered.length === 0 ? (
        <EmptyState title="No patients found" />
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Name</th><th>Email</th><th>Phone</th><th>Blood group</th><th></th></tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id}>
                  <td>{p.name}</td>
                  <td>{p.email}</td>
                  <td className="mono">{p.phone}</td>
                  <td>{p.blood_group || '—'}</td>
                  <td><Link to={`/patients/${p.id}`}>View chart →</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
