import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { appointmentsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';
import { useAuth } from '../context/AuthContext';

export default function Appointments() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const { data } = await appointmentsApi.mine();
        setAppointments(data);
      } catch (err) {
        setError(apiErrorMessage(err));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">{user.role === 'patient' ? 'Care' : 'Schedule'}</span>
          <h1>My appointments</h1>
          <p>{user.role === 'patient' ? 'Track your visits from booking through follow-up.' : 'Your consultation queue, most recent first.'}</p>
        </div>
        {user.role === 'patient' && <Link to="/doctors" className="btn btn--primary">Book new appointment</Link>}
      </div>

      <ErrorBanner message={error} />

      {loading ? <Loading /> : appointments.length === 0 ? (
        <EmptyState
          title="No appointments yet"
          hint={user.role === 'patient' ? 'Find a doctor and book your first visit.' : 'Appointments booked with you will appear here.'}
          action={user.role === 'patient' ? <Link to="/doctors" className="btn btn--primary">Find a doctor</Link> : null}
        />
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Time</th>
                <th>Reason</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((a) => (
                <tr key={a.id}>
                  <td className="mono">{a.slot_date}</td>
                  <td className="mono">{a.slot_time}</td>
                  <td>{a.reason || '—'}</td>
                  <td><StatusBadge status={a.status} /></td>
                  <td><Link to={`/appointments/${a.id}`}>View →</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
