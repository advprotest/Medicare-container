import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { appointmentsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';

const STATUS_OPTIONS = ['', 'booked', 'checked_in', 'in_consultation', 'completed', 'cancelled'];
const NEXT_ACTION = {
  booked: { label: 'Check in', next: 'checked_in' },
  checked_in: { label: 'Start consultation', next: 'in_consultation' },
};

export default function AppointmentQueue() {
  const [appointments, setAppointments] = useState([]);
  const [status, setStatus] = useState('');
  const [date, setDate] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actingId, setActingId] = useState(null);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const { data } = await appointmentsApi.all({
        status: status || undefined,
        slot_date: date || undefined,
      });
      setAppointments(data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [status, date]);

  async function handleAdvance(appt) {
    const action = NEXT_ACTION[appt.status];
    if (!action) return;
    setActingId(appt.id);
    setError('');
    try {
      await appointmentsApi.updateStatus(appt.id, action.next);
      await load();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setActingId(null);
    }
  }

  async function handleCancel(appt) {
    setActingId(appt.id);
    setError('');
    try {
      await appointmentsApi.updateStatus(appt.id, 'cancelled');
      await load();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setActingId(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Front desk</span>
          <h1>Appointment queue</h1>
          <p>Move patients through the pathway — check in, start consultation, or cancel.</p>
        </div>
      </div>

      <div className="row" style={{ marginBottom: 20 }}>
        <select value={status} onChange={(e) => setStatus(e.target.value)} style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)' }}>
          {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s ? s.replace(/_/g, ' ') : 'All statuses'}</option>)}
        </select>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)' }} />
        {(status || date) && <button className="btn btn--ghost btn--sm" onClick={() => { setStatus(''); setDate(''); }}>Clear filters</button>}
      </div>

      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading ? <Loading /> : appointments.length === 0 ? (
        <EmptyState title="No appointments match these filters" />
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th><th>Time</th><th>Reason</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((a) => {
                const action = NEXT_ACTION[a.status];
                return (
                  <tr key={a.id}>
                    <td className="mono">{a.slot_date}</td>
                    <td className="mono">{a.slot_time}</td>
                    <td>{a.reason || '—'}</td>
                    <td><StatusBadge status={a.status} /></td>
                    <td>
                      <div className="row">
                        <Link to={`/appointments/${a.id}`}>View</Link>
                        {action && (
                          <button className="btn btn--sm btn--primary" disabled={actingId === a.id} onClick={() => handleAdvance(a)}>
                            {action.label}
                          </button>
                        )}
                        {['booked', 'checked_in'].includes(a.status) && (
                          <button className="btn btn--sm btn--danger" disabled={actingId === a.id} onClick={() => handleCancel(a)}>
                            Cancel
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}