import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { doctorsApi, appointmentsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import Modal from '../components/Modal';
import { useAuth } from '../context/AuthContext';

function BookingModal({ doctor, onClose, onBooked }) {
  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(true);
  const [selected, setSelected] = useState(null);
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await doctorsApi.getSchedule(doctor.id);
        setSlots((data.slots || []).filter((s) => !s.is_booked));
      } catch (err) {
        setError(apiErrorMessage(err));
      } finally {
        setLoadingSlots(false);
      }
    })();
  }, [doctor.id]);

  async function handleBook() {
    if (!selected) return;
    setSubmitting(true);
    setError('');
    try {
      await appointmentsApi.book({
        doctor_id: doctor.id,
        slot_date: selected.slot_date,
        slot_time: selected.slot_time,
        reason: reason || undefined,
      });
      onBooked();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title={`Book with Dr. ${doctor.name}`} onClose={onClose}>
      <ErrorBanner message={error} onDismiss={() => setError('')} />
      {loadingSlots ? <Loading label="Loading available slots…" /> : slots.length === 0 ? (
        <EmptyState title="No open slots" hint="This doctor hasn't published any available slots yet." />
      ) : (
        <>
          <div className="field">
            <label>Available slots</label>
            <div className="pill-list">
              {slots.map((s, i) => (
                <button
                  type="button"
                  key={i}
                  className="btn btn--sm"
                  style={{
                    background: selected === s ? 'var(--color-primary)' : 'var(--color-surface-sunken)',
                    color: selected === s ? '#fff' : 'var(--color-ink)',
                  }}
                  onClick={() => setSelected(s)}
                >
                  {s.slot_date} · {s.slot_time}
                </button>
              ))}
            </div>
          </div>
          <div className="field">
            <label htmlFor="reason">Reason for visit (optional)</label>
            <textarea id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Briefly describe your symptoms" />
          </div>
          <button className="btn btn--primary" style={{ width: '100%' }} disabled={!selected || submitting} onClick={handleBook}>
            {submitting ? 'Booking…' : 'Confirm booking'}
          </button>
        </>
      )}
    </Modal>
  );
}

export default function Doctors() {
  const { user } = useAuth();
  const [doctors, setDoctors] = useState([]);
  const [specialization, setSpecialization] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [bookingDoctor, setBookingDoctor] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');

  async function load() {
    setLoading(true);
    setError('');
    try {
      const { data } = await doctorsApi.list(specialization || undefined);
      setDoctors(data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  function handleSearch(e) {
    e.preventDefault();
    load();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Directory</span>
          <h1>Doctors</h1>
          <p>Browse specialists and their published availability.</p>
        </div>
      </div>

      <form onSubmit={handleSearch} className="row" style={{ marginBottom: 20 }}>
        <input
          placeholder="Filter by specialization…"
          value={specialization}
          onChange={(e) => setSpecialization(e.target.value)}
          style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)', minWidth: 240 }}
        />
        <button type="submit" className="btn btn--ghost">Search</button>
      </form>

      {successMsg && <div className="success-banner">{successMsg}</div>}
      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading ? <Loading /> : doctors.length === 0 ? (
        <EmptyState title="No doctors found" hint="Try a different specialization, or check back later." />
      ) : (
        <div className="grid grid-cols-3">
          {doctors.map((doc) => (
            <div className="card" key={doc.id}>
              <h3>Dr. {doc.name}</h3>
              <p className="muted" style={{ marginBottom: 4 }}>{doc.specialization} · {doc.department}</p>
              <p style={{ fontSize: '0.85rem', marginBottom: 14 }}>{doc.experience_years} yrs experience · ₹{doc.fees} consultation fee</p>
              <div className="row">
                <Link to={`/doctors/${doc.id}`} className="btn btn--ghost btn--sm">View schedule</Link>
                {user.role === 'patient' && (
                  <button className="btn btn--primary btn--sm" onClick={() => setBookingDoctor(doc)}>Book</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {bookingDoctor && (
        <BookingModal
          doctor={bookingDoctor}
          onClose={() => setBookingDoctor(null)}
          onBooked={() => {
            setBookingDoctor(null);
            setSuccessMsg('Appointment booked successfully.');
          }}
        />
      )}
    </div>
  );
}
