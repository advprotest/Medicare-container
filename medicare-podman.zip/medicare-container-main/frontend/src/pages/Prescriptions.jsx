import { useState } from 'react';
import { prescriptionsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';

export default function Prescriptions() {
  const [mode, setMode] = useState('patient');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSearch(e) {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError('');
    setResults(null);
    try {
      if (mode === 'patient') {
        const { data } = await prescriptionsApi.forPatient(query.trim());
        setResults(data);
      } else {
        const { data } = await prescriptionsApi.forAppointment(query.trim());
        setResults([data]);
      }
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Dispensary</span>
          <h1>Prescription lookup</h1>
          <p>Search by patient ID or appointment ID to review what's been prescribed.</p>
        </div>
      </div>

      <form onSubmit={handleSearch} className="row" style={{ marginBottom: 20 }}>
        <select value={mode} onChange={(e) => setMode(e.target.value)} style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)' }}>
          <option value="patient">By patient ID</option>
          <option value="appointment">By appointment ID</option>
        </select>
        <input
          placeholder={mode === 'patient' ? 'Patient ID' : 'Appointment ID'}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)', minWidth: 260 }}
        />
        <button type="submit" className="btn btn--primary">Search</button>
      </form>

      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading && <Loading />}
      {results && results.length === 0 && <EmptyState title="No prescriptions found" />}
      {results && results.length > 0 && (
        <div className="grid grid-cols-2">
          {results.map((p) => (
            <div className="card" key={p.id}>
              <h3>Appointment {p.appointment_id.slice(-6)}</h3>
              <div className="pill-list">
                {p.medicines.map((m, i) => (
                  <span key={i} className="pill">{m.medicine_name} · {m.dosage} · {m.frequency} · {m.duration}</span>
                ))}
              </div>
              {p.instructions && <p className="muted spacer-top">{p.instructions}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
