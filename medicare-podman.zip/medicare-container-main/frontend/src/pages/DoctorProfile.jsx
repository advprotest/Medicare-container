import { useEffect, useState } from 'react';
import { doctorsApi, usersApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, ErrorBanner } from '../components/Feedback';

const EMPTY_SLOT = { slot_date: '', slot_time: '', is_booked: false };

export default function DoctorProfile() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [slots, setSlots] = useState([]);
  const [form, setForm] = useState({ specialization: '', experience_years: 0, fees: 0, department: 'General' });

  useEffect(() => {
    (async () => {
      try {
        const me = await usersApi.me();
        const { data: doctors } = await doctorsApi.list();
        const mine = doctors.find((d) => d.email === me.data.email);
        if (mine) {
          setForm({
            specialization: mine.specialization || '',
            experience_years: mine.experience_years || 0,
            fees: mine.fees || 0,
            department: mine.department || 'General',
          });
          const { data: sched } = await doctorsApi.getSchedule(mine.id);
          setSlots(sched.slots || []);
        }
      } catch (err) {
        setError(apiErrorMessage(err));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function handleProfileSave(e) {
    e.preventDefault();
    setSavingProfile(true);
    setError('');
    setSuccess('');
    try {
      await doctorsApi.updateMe({
        specialization: form.specialization,
        experience_years: Number(form.experience_years) || 0,
        fees: Number(form.fees) || 0,
        department: form.department,
      });
      setSuccess('Profile updated.');
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSavingProfile(false);
    }
  }

  function addSlotRow() {
    setSlots((s) => [...s, { ...EMPTY_SLOT }]);
  }

  function updateSlot(i, key, value) {
    setSlots((s) => s.map((slot, idx) => (idx === i ? { ...slot, [key]: value } : slot)));
  }

  function removeSlot(i) {
    setSlots((s) => s.filter((_, idx) => idx !== i));
  }

  async function handleScheduleSave() {
    setSavingSchedule(true);
    setError('');
    setSuccess('');
    try {
      const cleaned = slots.filter((s) => s.slot_date && s.slot_time);
      await doctorsApi.setMySchedule(cleaned);
      setSlots(cleaned);
      setSuccess('Schedule published.');
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSavingSchedule(false);
    }
  }

  if (loading) return <Loading />;

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">My profile</span>
          <h1>Profile &amp; schedule</h1>
          <p>Keep your specialty details current and publish the slots patients can book.</p>
        </div>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError('')} />
      {success && <div className="success-banner">{success}</div>}

      <div className="grid grid-cols-2">
        <div className="card">
          <h3>Profile details</h3>
          <form onSubmit={handleProfileSave}>
            <div className="form-row">
              <div className="field">
                <label htmlFor="specialization">Specialization</label>
                <input id="specialization" required value={form.specialization} onChange={(e) => setForm({ ...form, specialization: e.target.value })} placeholder="Cardiology" />
              </div>
              <div className="field">
                <label htmlFor="department">Department</label>
                <input id="department" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} placeholder="General" />
              </div>
            </div>
            <div className="form-row">
              <div className="field">
                <label htmlFor="experience">Years of experience</label>
                <input id="experience" type="number" min="0" value={form.experience_years} onChange={(e) => setForm({ ...form, experience_years: e.target.value })} />
              </div>
              <div className="field">
                <label htmlFor="fees">Consultation fee (₹)</label>
                <input id="fees" type="number" min="0" step="0.01" required value={form.fees} onChange={(e) => setForm({ ...form, fees: e.target.value })} />
              </div>
            </div>
            <button className="btn btn--primary" type="submit" disabled={savingProfile}>
              {savingProfile ? 'Saving…' : 'Save profile'}
            </button>
          </form>
        </div>

        <div className="card">
          <h3>Available slots</h3>
          <div className="stack">
            {slots.map((slot, i) => (
              <div className="row" key={i}>
                <input type="date" value={slot.slot_date} onChange={(e) => updateSlot(i, 'slot_date', e.target.value)} />
                <input type="time" value={slot.slot_time} onChange={(e) => updateSlot(i, 'slot_time', e.target.value)} />
                <button type="button" className="icon-button" onClick={() => removeSlot(i)} aria-label="Remove slot">×</button>
              </div>
            ))}
            <button type="button" className="btn btn--ghost btn--sm" onClick={addSlotRow}>+ Add slot</button>
          </div>
          <button className="btn btn--accent spacer-top" onClick={handleScheduleSave} disabled={savingSchedule}>
            {savingSchedule ? 'Publishing…' : 'Publish schedule'}
          </button>
        </div>
      </div>
    </div>
  );
}
