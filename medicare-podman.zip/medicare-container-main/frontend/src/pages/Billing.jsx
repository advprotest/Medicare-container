import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { billingApi, patientsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';
import { useAuth } from '../context/AuthContext';

function PatientInvoices() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const { data: me } = await patientsApi.me();
        const { data } = await billingApi.forPatient(me.id);
        setInvoices(data);
      } catch (err) {
        setError(apiErrorMessage(err));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <Loading />;
  if (error) return <ErrorBanner message={error} />;
  if (invoices.length === 0) return <EmptyState title="No invoices yet" hint="Invoices appear here after a visit is billed." />;

  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Invoice</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead>
        <tbody>
          {invoices.map((inv) => (
            <tr key={inv.id}>
              <td className="mono">#{inv.invoice_no}</td>
              <td>₹{inv.amount}</td>
              <td style={{ textTransform: 'capitalize' }}>{inv.payment_method}</td>
              <td><StatusBadge status={inv.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StaffBilling() {
  const [searchParams] = useSearchParams();
  const [pending, setPending] = useState([]);
  const [loadingList, setLoadingList] = useState(true);
  const [invoiceNo, setInvoiceNo] = useState(searchParams.get('invoice') || '');
  const [invoice, setInvoice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [reference, setReference] = useState('');
  const [amountReceived, setAmountReceived] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  async function loadPending() {
    setLoadingList(true);
    try {
      const { data } = await billingApi.all('pending');
      setPending(data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoadingList(false);
    }
  }

  useEffect(() => { loadPending(); }, []);

  async function handleLookup(e) {
    e?.preventDefault();
    if (!invoiceNo) return;
    setLoading(true);
    setError('');
    setInvoice(null);
    try {
      const { data } = await billingApi.getInvoice(Number(invoiceNo));
      setInvoice(data);
      setAmountReceived(data.amount);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (searchParams.get('invoice')) handleLookup();
    // eslint-disable-next-line
  }, []);

  function selectFromDropdown(id) {
    setSuccess('');
    setError('');
    if (!id) {
      setInvoice(null);
      setInvoiceNo('');
      return;
    }
    const found = pending.find((p) => p.id === id);
    if (found) {
      setInvoice(found);
      setInvoiceNo(String(found.invoice_no));
      setAmountReceived(found.amount);
      setReference('');
    }
  }

  async function handleConfirm(e) {
    e.preventDefault();
    setConfirming(true);
    setError('');
    try {
      const payload = { invoice_no: invoice.invoice_no };
      if (invoice.payment_method === 'online') payload.gateway_payment_id = reference;
      if (invoice.payment_method === 'offline') payload.amount_received = Number(amountReceived);
      await billingApi.confirm(payload);
      setSuccess(`Payment confirmed for invoice #${invoice.invoice_no}. It now reflects in the dashboard's revenue.`);
      setInvoice(null);
      setInvoiceNo('');
      setReference('');
      loadPending();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setConfirming(false);
    }
  }

  return (
    <div>
      <div className="field" style={{ maxWidth: 420, marginBottom: 12 }}>
        <label htmlFor="pending-invoice">Pending invoices</label>
        <select id="pending-invoice" value={invoice?.id || ''} onChange={(e) => selectFromDropdown(e.target.value)} disabled={loadingList}>
          <option value="">{loadingList ? 'Loading…' : pending.length === 0 ? 'No pending invoices' : 'Select an invoice…'}</option>
          {pending.map((p) => (
            <option key={p.id} value={p.id}>
              #{p.invoice_no} · ₹{p.amount} · {p.payment_method}
            </option>
          ))}
        </select>
        <p className="muted" style={{ fontSize: '0.8rem' }}>New bills appear here automatically; a bill drops off this list once its payment is confirmed.</p>
      </div>

      <form onSubmit={handleLookup} className="row" style={{ marginBottom: 20 }}>
        <input
          placeholder="…or look up by invoice number"
          type="number"
          value={invoiceNo}
          onChange={(e) => setInvoiceNo(e.target.value)}
          style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)', minWidth: 200 }}
        />
        <button type="submit" className="btn btn--primary">Look up</button>
      </form>

      <ErrorBanner message={error} onDismiss={() => setError('')} />
      {success && <div className="success-banner">{success}</div>}

      {loading && <Loading />}
      {invoice && (
        <div className="card" style={{ maxWidth: 480 }}>
          <div className="row-between" style={{ marginBottom: 10 }}>
            <h3 style={{ margin: 0 }}>Invoice #{invoice.invoice_no}</h3>
            <StatusBadge status={invoice.status} />
          </div>
          <div className="stack" style={{ marginBottom: 14 }}>
            {invoice.line_items.map((it, i) => (
              <div className="row-between" key={i}>
                <span>{it.description}</span>
                <span className="mono">₹{it.amount}</span>
              </div>
            ))}
          </div>
          <div className="row-between" style={{ fontWeight: 700, borderTop: '1px solid var(--color-line)', paddingTop: 10, marginBottom: 14 }}>
            <span>Total</span>
            <span className="mono">₹{invoice.amount}</span>
          </div>
          {invoice.status === 'pending' && (
            <form onSubmit={handleConfirm}>
              {invoice.payment_method === 'online' && (
                <div className="field">
                  <label htmlFor="reference">UPI ID / GPay reference</label>
                  <input id="reference" required value={reference} onChange={(e) => setReference(e.target.value)} placeholder="e.g. UPI ref no. or GPay transaction ID" />
                </div>
              )}
              {invoice.payment_method === 'offline' && (
                <div className="field">
                  <label htmlFor="amountReceived">Amount received (₹)</label>
                  <input id="amountReceived" type="number" min="0" step="0.01" required value={amountReceived} onChange={(e) => setAmountReceived(e.target.value)} />
                </div>
              )}
              <button className="btn btn--primary" type="submit" disabled={confirming}>
                {confirming ? 'Confirming…' : 'Confirm payment received'}
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}

export default function Billing() {
  const { user } = useAuth();

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Billing</span>
          <h1>{user.role === 'patient' ? 'My invoices' : 'Invoice lookup'}</h1>
          <p>{user.role === 'patient' ? 'Every invoice generated for your visits.' : 'Look up an invoice by number and confirm payment.'}</p>
        </div>
      </div>
      {user.role === 'patient' ? <PatientInvoices /> : <StaffBilling />}
    </div>
  );
}