import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
  PieChart, Pie, Cell, Legend,
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { reportsApi, appointmentsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';

const DEPT_COLORS = ['#0B6E63', '#D98F2B', '#2F6FA3', '#C0392B', '#6A5AAE', '#2F9E6E'];

function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [trend, setTrend] = useState([]);
  const [depts, setDepts] = useState([]);
  const [recentAppts, setRecentAppts] = useState([]);
  const [recentPayments, setRecentPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const [d, t, dep, ra, rp] = await Promise.all([
          reportsApi.dashboard(),
          reportsApi.appointmentsTrend(30),
          reportsApi.departmentWisePatients(),
          reportsApi.recentAppointments(6),
          reportsApi.recentPayments(6),
        ]);
        setStats(d.data);
        setTrend(t.data);
        setDepts(dep.data);
        setRecentAppts(ra.data);
        setRecentPayments(rp.data);
      } catch (err) {
        setError(apiErrorMessage(err));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <Loading label="Loading dashboard…" />;
  if (error) return <div className="error-banner">{error}</div>;

  return (
    <div className="stack">
      <div className="grid grid-cols-4">
        <div className="stat-card">
          <div className="stat-card-label">Total patients</div>
          <div className="stat-card-value mono">{stats.total_patients}</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-label">Total doctors</div>
          <div className="stat-card-value mono">{stats.total_doctors}</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-label">Appointments closed</div>
          <div className="stat-card-value mono">{stats.appointments_today}</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-label">Revenue (MTD)</div>
          <div className="stat-card-value mono">₹{Number(stats.revenue_mtd).toLocaleString('en-IN')}</div>
        </div>
      </div>

      <div className="grid grid-cols-2">
        <div className="card">
          <h3>Appointments trend (30 days)</h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={trend}>
              <CartesianGrid stroke="#DCE4E2" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => v.slice(5)} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="appointments" stroke="#0B6E63" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <h3>Department-wise patients</h3>
          {depts.length === 0 ? <p className="muted">No data yet.</p> : (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={depts} dataKey="count" nameKey="department" innerRadius={55} outerRadius={85} paddingAngle={2}>
                  {depts.map((_, i) => <Cell key={i} fill={DEPT_COLORS[i % DEPT_COLORS.length]} />)}
                </Pie>
                <Legend />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2">
        <div className="card">
          <h3>Recent appointments</h3>
          {recentAppts.length === 0 ? <p className="muted">No appointments yet.</p> : (
            <div className="stack" style={{ gap: 10 }}>
              {recentAppts.map((a, i) => (
                <div className="row-between" key={i}>
                  <span className="mono" style={{ fontSize: '0.82rem' }}>{a.slot_date} · {a.slot_time}</span>
                  <StatusBadge status={a.status} />
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="card">
          <h3>Recent payments</h3>
          {recentPayments.length === 0 ? <p className="muted">No payments yet.</p> : (
            <div className="stack" style={{ gap: 10 }}>
              {recentPayments.map((p, i) => (
                <div className="row-between" key={i}>
                  <span className="mono" style={{ fontSize: '0.82rem' }}>Invoice #{p.invoice_no} · ₹{p.amount}</span>
                  <StatusBadge status={p.status} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function GenericOverview({ user }) {
  const [upcoming, setUpcoming] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await appointmentsApi.mine();
        setUpcoming(data.slice(0, 5));
      } catch {
        setUpcoming([]);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const quickLinks = {
    patient: [
      { to: '/doctors', label: 'Book an appointment' },
      { to: '/appointments', label: 'View my appointments' },
      { to: '/billing', label: 'View my invoices' },
    ],
    doctor: [
      { to: '/appointments', label: 'My appointment queue' },
      { to: '/patients', label: 'Search patients' },
      { to: '/doctor-profile', label: 'Manage my schedule' },
    ],
    nurse: [
      { to: '/appointment-queue', label: 'Appointment queue' },
      { to: '/patients', label: 'Patient directory' },
    ],
    receptionist: [
      { to: '/appointment-queue', label: 'Appointment queue' },
      { to: '/billing', label: 'Generate a bill' },
    ],
    lab_technician: [
      { to: '/lab-tests', label: 'Lab test queue' },
    ],
    pharmacist: [
      { to: '/pharmacy', label: 'Manage inventory' },
      { to: '/prescriptions', label: 'Look up prescriptions' },
    ],
  };

  const links = quickLinks[user.role] || [];

  return (
    <div className="stack">
      <div className="grid grid-cols-2">
        <div className="card">
          <h3>Welcome back, {user.name.split(' ')[0]}</h3>
          <p className="muted">Here's a quick jump into what you'd usually do next.</p>
          <div className="pill-list">
            {links.map((l) => (
              <Link key={l.to} to={l.to} className="pill" style={{ textDecoration: 'none', color: 'var(--color-primary-dark)', fontWeight: 600 }}>
                {l.label} →
              </Link>
            ))}
          </div>
        </div>
        <div className="card">
          <h3>{user.role === 'doctor' ? 'Upcoming appointments' : 'Your recent appointments'}</h3>
          {loading ? <Loading /> : upcoming.length === 0 ? (
            <p className="muted">Nothing here yet.</p>
          ) : (
            <div className="stack" style={{ gap: 10 }}>
              {upcoming.map((a) => (
                <div className="row-between" key={a.id}>
                  <span className="mono" style={{ fontSize: '0.82rem' }}>{a.slot_date} · {a.slot_time}</span>
                  <StatusBadge status={a.status} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Overview</span>
          <h1>{user.role === 'admin' ? 'Hospital dashboard' : `Welcome, ${user.name.split(' ')[0]}`}</h1>
          <p>Smart Healthcare. Better Management. Better Care.</p>
        </div>
      </div>
      {user.role === 'admin' ? <AdminDashboard /> : <GenericOverview user={user} />}
    </div>
  );
}
