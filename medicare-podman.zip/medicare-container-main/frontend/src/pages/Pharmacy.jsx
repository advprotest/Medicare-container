import { useEffect, useState } from 'react';
import { pharmacyApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import Modal from '../components/Modal';
import { useAuth } from '../context/AuthContext';

function AddMedicineModal({ onClose, onSaved, setError }) {
  const [form, setForm] = useState({ name: '', category: '', unit_price: '', quantity_in_stock: '', reorder_level: 20 });
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await pharmacyApi.add({
        name: form.name,
        category: form.category || undefined,
        unit_price: Number(form.unit_price),
        quantity_in_stock: Number(form.quantity_in_stock),
        reorder_level: Number(form.reorder_level) || 20,
      });
      onSaved();
    } catch (err) {
      setError(apiErrorMessage(err));
      onClose();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal title="Add medicine" onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <div className="field">
          <label htmlFor="name">Name</label>
          <input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div className="field">
          <label htmlFor="category">Category</label>
          <input id="category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Analgesic, Antibiotic…" />
        </div>
        <div className="form-row">
          <div className="field">
            <label htmlFor="price">Unit price (₹)</label>
            <input id="price" type="number" min="0" step="0.01" required value={form.unit_price} onChange={(e) => setForm({ ...form, unit_price: e.target.value })} />
          </div>
          <div className="field">
            <label htmlFor="qty">Quantity in stock</label>
            <input id="qty" type="number" min="0" required value={form.quantity_in_stock} onChange={(e) => setForm({ ...form, quantity_in_stock: e.target.value })} />
          </div>
        </div>
        <div className="field">
          <label htmlFor="reorder">Reorder level</label>
          <input id="reorder" type="number" min="0" value={form.reorder_level} onChange={(e) => setForm({ ...form, reorder_level: e.target.value })} />
        </div>
        <button className="btn btn--primary" type="submit" disabled={saving}>{saving ? 'Adding…' : 'Add medicine'}</button>
      </form>
    </Modal>
  );
}

export default function Pharmacy() {
  const { user } = useAuth();
  const [medicines, setMedicines] = useState([]);
  const [lowStockOnly, setLowStockOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [busyId, setBusyId] = useState(null);

  const canManage = ['pharmacist', 'admin'].includes(user.role);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const { data } = await pharmacyApi.list(lowStockOnly);
      setMedicines(data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [lowStockOnly]);

  async function adjustStock(medicine, delta) {
    setBusyId(medicine.id);
    setError('');
    try {
      await pharmacyApi.updateStock(medicine.id, delta);
      await load();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Inventory</span>
          <h1>Pharmacy</h1>
          <p>Track stock levels and dispense or restock medicine.</p>
        </div>
        {canManage && <button className="btn btn--primary" onClick={() => setShowAdd(true)}>Add medicine</button>}
      </div>

      <label className="row" style={{ marginBottom: 20, fontSize: '0.86rem' }}>
        <input type="checkbox" checked={lowStockOnly} onChange={(e) => setLowStockOnly(e.target.checked)} />
        Show low-stock only
      </label>

      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading ? <Loading /> : medicines.length === 0 ? (
        <EmptyState title="No medicines found" />
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Name</th><th>Category</th><th>Unit price</th><th>In stock</th><th>Reorder level</th>{canManage && <th></th>}</tr></thead>
            <tbody>
              {medicines.map((m) => (
                <tr key={m.id}>
                  <td>{m.name}</td>
                  <td>{m.category || '—'}</td>
                  <td>₹{m.unit_price}</td>
                  <td className="mono" style={{ color: m.quantity_in_stock <= m.reorder_level ? 'var(--color-danger)' : undefined, fontWeight: m.quantity_in_stock <= m.reorder_level ? 700 : 400 }}>
                    {m.quantity_in_stock}
                  </td>
                  <td className="mono">{m.reorder_level}</td>
                  {canManage && (
                    <td>
                      <div className="row">
                        <button className="btn btn--sm btn--ghost" disabled={busyId === m.id} onClick={() => adjustStock(m, 10)}>+10 restock</button>
                        <button className="btn btn--sm btn--ghost" disabled={busyId === m.id || m.quantity_in_stock < 1} onClick={() => adjustStock(m, -1)}>-1 dispense</button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showAdd && (
        <AddMedicineModal onClose={() => setShowAdd(false)} onSaved={() => { setShowAdd(false); load(); }} setError={setError} />
      )}
    </div>
  );
}
