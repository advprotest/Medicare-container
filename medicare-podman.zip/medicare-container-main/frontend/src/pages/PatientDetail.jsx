import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { patientsApi, labTestsApi, prescriptionsApi, billingApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, ErrorBanner } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';
import { useAuth } from '../context/AuthContext';

export default function PatientDetail() {
  const { patientId } = useParams();
  const { user } = useAuth();
  const [patient, setPatient] = useState(null);
  const [labTests, setLabTests] = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [note, setNote] = useState('');
  const [savingNote, setSavingNote] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  async function loadAll() {
    setLoading(true);
    setError('');
    try {
      const { data } = await patientsApi.get(patientId);
      setPatient(data);
      const [labs, rx, bills] = await Promise.all([
        labTestsApi.forPatient(data.user_id),
        prescriptionsApi.forPatient(data.user_id),
        billingApi.forPatient(data.user_id).catch(() => ({ data: [] })),
      ]);
      setLabTests(labs.data);
      setPrescriptions(rx.data);
      setInvoices(bills.data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadAll(); /* eslint-disable-next-line */ }, [patientId]);

  async function handleAddNote(e) {
    e.preventDefault();
    setSavingNote(true);
    setError('');
    try {
      await patientsApi.addMedicalHistory(patientId, note);
      setNote('');
      setSuccess('Medical history note added.');
      loadAll();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSavingNote(false);
    }
  }

  if (loading) return <Loading />;
  if (!patient) return <ErrorBanner message={error || 'Patient not found.'} />;

  const canAddNote = ['doctor', 'admin'].includes(user.role);

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Patient chart</span>
          <h1>{patient.name}</h1>
          <p>{patient.email} · {patient.phone} {patient.blood_group ? `· ${patient.blood_group}` : ''}</p>
        </div>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError('')} />
      {success && <div className="success-banner">{success}</div>}

      <div className="grid grid-cols-2">
        <div className="card">
          <h3>Profile</h3>
          <div className="stack" style={{ gap: 6, fontSize: '0.88rem' }}>
            <div><strong>Age:</strong> {patient.age ?? '—'}</div>
            <div><strong>Gender:</strong> {patient.gender ?? '—'}</div>
            <div><strong>Address:</strong> {patient.address ?? '—'}</div>
            <div><strong>Emergency contact:</strong> {patient.emergency_contact ?? '—'}</div>
          </div>
        </div>

        <div className="card">
          <h3>Medical history</h3>
          {patient.medical_history.length === 0 ? <p className="muted">No history recorded yet.</p> : (
            <ul style={{ paddingLeft: 18, margin: 0 }}>
              {patient.medical_history.map((h, i) => <li key={i} style={{ marginBottom: 6 }}>{h}</li>)}
            </ul>
          )}
          {canAddNote && (
            <form onSubmit={handleAddNote} className="spacer-top">
              <div className="field">
                <label htmlFor="note">Add a note</label>
                <textarea id="note" required value={note} onChange={(e) => setNote(e.target.value)} placeholder="Observation, allergy, ongoing condition…" />
              </div>
              <button className="btn btn--ghost btn--sm" type="submit" disabled={savingNote}>{savingNote ? 'Saving…' : 'Add note'}</button>
            </form>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 spacer-top">
        <div className="card">
          <h3>Lab tests</h3>
          {labTests.length === 0 ? <p className="muted">No lab tests on record.</p> : (
            <div className="stack">
              {labTests.map((t) => (
                <div className="row-between" key={t.id}>
                  <span>{t.test_name}</span>
                  <StatusBadge status={t.status} />
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="card">
          <h3>Prescriptions</h3>
          {prescriptions.length === 0 ? <p className="muted">No prescriptions on record.</p> : (
            <div className="stack">
              {prescriptions.map((p) => (
                <div key={p.id} className="pill" style={{ display: 'block' }}>
                  {p.medicines.map((m) => m.medicine_name).join(', ')}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="card spacer-top">
        <h3>Invoices</h3>
        {invoices.length === 0 ? <p className="muted">No invoices on record.</p> : (
          <div className="table-wrap">
            <table className="data-table">
              <thead><tr><th>Invoice</th><th>Amount</th><th>Status</th></tr></thead>
              <tbody>
                {invoices.map((inv) => (
                  <tr key={inv.id}>
                    <td className="mono">#{inv.invoice_no}</td>
                    <td>₹{inv.amount}</td>
                    <td><StatusBadge status={inv.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}