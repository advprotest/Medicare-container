import { useEffect, useState } from 'react';
import { labTestsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';
import { useAuth } from '../context/AuthContext';

const STATUS_OPTIONS = ['', 'ordered', 'sample_collected', 'result_uploaded', 'reviewed'];

function UploadResultModal({ test, onClose, onSaved, setError }) {
  const [summary, setSummary] = useState('');
  const [url, setUrl] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await labTestsApi.uploadResult(test.id, { result_summary: summary, report_file_url: url || undefined });
      onSaved();
    } catch (err) {
      setError(apiErrorMessage(err));
      onClose();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal title={`Upload result — ${test.test_name}`} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <div className="field">
          <label htmlFor="summary">Result summary</label>
          <textarea id="summary" required value={summary} onChange={(e) => setSummary(e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="url">Report file URL (optional)</label>
          <input id="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" />
        </div>
        <button className="btn btn--primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Upload result'}</button>
      </form>
    </Modal>
  );
}

export default function LabTests() {
  const { user } = useAuth();
  const [tests, setTests] = useState([]);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);
  const [uploadTarget, setUploadTarget] = useState(null);

  const isLabTech = ['lab_technician', 'admin'].includes(user.role);
  const isDoctor = ['doctor', 'admin'].includes(user.role);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const { data } = await labTestsApi.all(status || undefined);
      setTests(data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [status]);

  async function handleCollect(test) {
    setBusyId(test.id);
    setError('');
    try {
      await labTestsApi.collectSample(test.id);
      await load();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  }

  async function handleReview(test) {
    setBusyId(test.id);
    setError('');
    try {
      await labTestsApi.review(test.id);
      await load();
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Diagnostics</span>
          <h1>Lab tests</h1>
          <p>{isLabTech ? 'Process samples and publish results.' : 'Review results uploaded for your patients.'}</p>
        </div>
      </div>

      <select value={status} onChange={(e) => setStatus(e.target.value)} style={{ padding: '9px 12px', border: '1px solid var(--color-line-strong)', borderRadius: 'var(--radius-sm)', marginBottom: 20 }}>
        {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s ? s.replace(/_/g, ' ') : 'All statuses'}</option>)}
      </select>

      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading ? <Loading /> : tests.length === 0 ? (
        <EmptyState title="No lab tests match this filter" />
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Test</th><th>Status</th><th>Result</th><th></th></tr></thead>
            <tbody>
              {tests.map((t) => (
                <tr key={t.id}>
                  <td>{t.test_name}</td>
                  <td><StatusBadge status={t.status} /></td>
                  <td className="muted" style={{ maxWidth: 240 }}>{t.result_summary || '—'}</td>
                  <td>
                    <div className="row">
                      {isLabTech && t.status === 'ordered' && (
                        <button className="btn btn--sm btn--ghost" disabled={busyId === t.id} onClick={() => handleCollect(t)}>Collect sample</button>
                      )}
                      {isLabTech && t.status === 'sample_collected' && (
                        <button className="btn btn--sm btn--accent" disabled={busyId === t.id} onClick={() => setUploadTarget(t)}>Upload result</button>
                      )}
                      {isDoctor && t.status === 'result_uploaded' && (
                        <button className="btn btn--sm btn--primary" disabled={busyId === t.id} onClick={() => handleReview(t)}>Mark reviewed</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {uploadTarget && (
        <UploadResultModal
          test={uploadTarget}
          onClose={() => setUploadTarget(null)}
          onSaved={() => { setUploadTarget(null); load(); }}
          setError={setError}
        />
      )}
    </div>
  );
}
