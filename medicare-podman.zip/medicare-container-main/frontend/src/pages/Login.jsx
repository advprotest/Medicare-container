import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Cross } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiErrorMessage } from '../api/client';
import { ErrorBanner } from '../components/Feedback';

export default function Login() {
  const { login, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    try {
      await login(form.email, form.password);
      navigate(location.state?.from || '/', { replace: true });
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-visual">
        <span className="shell-brand-mark" style={{ marginBottom: 24 }}><Cross size={20} /></span>
        <h1>Smart healthcare, better managed.</h1>
        <p>One record, every department — registration through consultation, labs, prescriptions, and billing, all in sync.</p>
      </div>
      <div className="auth-form-side">
        <div className="auth-card">
          <h2>Sign in</h2>
          <p className="muted" style={{ marginBottom: 24 }}>Enter your credentials to reach your dashboard.</p>
          <ErrorBanner message={error} onDismiss={() => setError('')} />
          <form onSubmit={handleSubmit}>
            <div className="field">
              <label htmlFor="email">Email</label>
              <input
                id="email" type="email" required autoComplete="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="you@medicareplus.com"
              />
            </div>
            <div className="field">
              <label htmlFor="password">Password</label>
              <input
                id="password" type="password" required autoComplete="current-password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="••••••••"
              />
            </div>
            <button type="submit" className="btn btn--primary" style={{ width: '100%' }} disabled={loading}>
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>
          <p className="auth-switch">
            New here? <Link to="/register">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
