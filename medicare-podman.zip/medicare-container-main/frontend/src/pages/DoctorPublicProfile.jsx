import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doctorsApi, appointmentsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, EmptyState, ErrorBanner } from '../components/Feedback';
import Modal from '../components/Modal';
import { useAuth } from '../context/AuthContext';

export default function DoctorPublicProfile() {
  const { doctorId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [doctor, setDoctor] = useState(null);
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [pendingSlot, setPendingSlot] = useState(null);
  const [reason, setReason] = useState('');
  const [booking, setBooking] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [d, s] = await Promise.all([doctorsApi.get(doctorId), doctorsApi.getSchedule(doctorId)]);
        setDoctor(d.data);
        setSlots(s.data.slots || []);
      } catch (err) {
        setError(apiErrorMessage(err));
      } finally {
        setLoading(false);
      }
    })();
  }, [doctorId]);

  async function handleBook(e) {
    e.preventDefault();
    setBooking(true);
    setError('');
    try {
      await appointmentsApi.book({
        doctor_id: doctorId,
        slot_date: pendingSlot.slot_date,
        slot_time: pendingSlot.slot_time,
        reason: reason || undefined,
      });
      navigate('/appointments');
    } catch (err) {
      setError(apiErrorMessage(err));
      setPendingSlot(null);
    } finally {
      setBooking(false);
    }
  }

  if (loading) return <Loading />;
  if (error && !doctor) return <ErrorBanner message={error} />;

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">Doctor</span>
          <h1>Dr. {doctor.name}</h1>
          <p>{doctor.specialization} · {doctor.department} · {doctor.experience_years} yrs experience · ₹{doctor.fees} fee</p>
        </div>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError('')} />

      <div className="card">
        <h3>Published availability</h3>
        {slots.length === 0 ? (
          <EmptyState title="No slots published yet" />
        ) : (
          <div className="pill-list">
            {slots.map((s, i) => (
              <button
                type="button"
                key={i}
                className="btn btn--sm"
                disabled={s.is_booked || user.role !== 'patient'}
                style={{ background: s.is_booked ? 'var(--color-surface-sunken)' : 'var(--color-accent-tint)', color: s.is_booked ? 'var(--color-ink-soft)' : '#92600F' }}
                onClick={() => { setPendingSlot(s); setReason(''); }}
                title={s.is_booked ? 'Already booked' : user.role !== 'patient' ? 'Only patients can book' : 'Book this slot'}
              >
                {s.slot_date} · {s.slot_time} {s.is_booked ? '(booked)' : ''}
              </button>
            ))}
          </div>
        )}
      </div>

      {pendingSlot && (
        <Modal title="Confirm appointment" onClose={() => !booking && setPendingSlot(null)}>
          <form onSubmit={handleBook}>
            <p className="muted" style={{ marginTop: 0 }}>
              {pendingSlot.slot_date} · {pendingSlot.slot_time} with Dr. {doctor.name}
            </p>
            <div className="field">
              <label htmlFor="reason">Reason for visit</label>
              <textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Chest pain for the past two days"
                autoFocus
              />
              <p className="muted" style={{ fontSize: '0.8rem' }}>Visible to the doctor and admin staff.</p>
            </div>
            <button className="btn btn--primary" type="submit" disabled={booking}>
              {booking ? 'Booking…' : 'Confirm booking'}
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
}