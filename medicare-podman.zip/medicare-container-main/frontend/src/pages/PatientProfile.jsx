import { useEffect, useState } from 'react';
import { patientsApi, labTestsApi, prescriptionsApi } from '../api/endpoints';
import { apiErrorMessage } from '../api/client';
import { Loading, ErrorBanner } from '../components/Feedback';
import StatusBadge from '../components/StatusBadge';

const GENDERS = ['', 'male', 'female', 'other'];

export default function PatientProfile() {
  const [profile, setProfile] = useState(null);
  const [form, setForm] = useState(null);
  const [labTests, setLabTests] = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [tab, setTab] = useState('profile');

  async function loadAll() {
    setLoading(true);
    setError('');
    try {
      const { data } = await patientsApi.me();
      setProfile(data);
      setForm({
        age: data.age ?? '', gender: data.gender ?? '', address: data.address ?? '',
        blood_group: data.blood_group ?? '', emergency_contact: data.emergency_contact ?? '',
      });
      const [labs, rx] = await Promise.all([
        labTestsApi.forPatient(data.user_id),
        prescriptionsApi.forPatient(data.user_id),
      ]);
      setLabTests(labs.data);
      setPrescriptions(rx.data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadAll(); }, []);

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      const payload = {
        age: form.age === '' ? undefined : Number(form.age),
        gender: form.gender || undefined,
        address: form.address || undefined,
        blood_group: form.blood_group || undefined,
        emergency_contact: form.emergency_contact || undefined,
      };
      const { data } = await patientsApi.updateMe(payload);
      setProfile(data);
      setSuccess('Profile updated.');
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <Loading />;

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-header-eyebrow">My profile</span>
          <h1>{profile.name}</h1>
          <p>{profile.email} · {profile.phone}</p>
        </div>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError('')} />
      {success && <div className="success-banner">{success}</div>}

      <div className="tabs">
        <button className={`tab-btn ${tab === 'profile' ? 'is-active' : ''}`} onClick={() => setTab('profile')}>Profile</button>
        <button className={`tab-btn ${tab === 'history' ? 'is-active' : ''}`} onClick={() => setTab('history')}>Medical history</button>
        <button className={`tab-btn ${tab === 'labs' ? 'is-active' : ''}`} onClick={() => setTab('labs')}>Lab results</button>
        <button className={`tab-btn ${tab === 'rx' ? 'is-active' : ''}`} onClick={() => setTab('rx')}>Prescriptions</button>
      </div>

      {tab === 'profile' && (
        <div className="card" style={{ maxWidth: 520 }}>
          <form onSubmit={handleSave}>
            <div className="form-row">
              <div className="field">
                <label htmlFor="age">Age</label>
                <input id="age" type="number" min="0" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} />
              </div>
              <div className="field">
                <label htmlFor="gender">Gender</label>
                <select id="gender" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                  {GENDERS.map((g) => <option key={g} value={g}>{g || 'Prefer not to say'}</option>)}
                </select>
              </div>
            </div>
            <div className="field">
              <label htmlFor="address">Address</label>
              <input id="address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            </div>
            <div className="form-row">
              <div className="field">
                <label htmlFor="bg">Blood group</label>
                <input id="bg" value={form.blood_group} onChange={(e) => setForm({ ...form, blood_group: e.target.value })} placeholder="O+" />
              </div>
              <div className="field">
                <label htmlFor="ec">Emergency contact</label>
                <input id="ec" value={form.emergency_contact} onChange={(e) => setForm({ ...form, emergency_contact: e.target.value })} />
              </div>
            </div>
            <button className="btn btn--primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</button>
          </form>
        </div>
      )}

      {tab === 'history' && (
        <div className="card">
          {profile.medical_history.length === 0 ? <p className="muted">No history recorded yet.</p> : (
            <ul style={{ paddingLeft: 18, margin: 0 }}>
              {profile.medical_history.map((h, i) => <li key={i} style={{ marginBottom: 6 }}>{h}</li>)}
            </ul>
          )}
        </div>
      )}

      {tab === 'labs' && (
        <div className="card">
          {labTests.length === 0 ? <p className="muted">No lab tests on record.</p> : (
            <div className="stack">
              {labTests.map((t) => (
                <div key={t.id} className="row-between">
                  <div>
                    <div style={{ fontWeight: 600 }}>{t.test_name}</div>
                    {t.result_summary && <div className="muted" style={{ fontSize: '0.82rem' }}>{t.result_summary}</div>}
                  </div>
                  <StatusBadge status={t.status} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'rx' && (
        <div className="card">
          {prescriptions.length === 0 ? <p className="muted">No prescriptions on record.</p> : (
            <div className="stack">
              {prescriptions.map((p) => (
                <div key={p.id} className="card card--tight">
                  {p.medicines.map((m, i) => (
                    <div key={i} className="pill" style={{ display: 'inline-block', marginRight: 6, marginBottom: 6 }}>
                      {m.medicine_name} · {m.dosage} · {m.frequency} · {m.duration}
                    </div>
                  ))}
                  {p.instructions && <p className="muted" style={{ marginTop: 8 }}>{p.instructions}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}