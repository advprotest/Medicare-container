const TONE_MAP = {
  booked: 'info', checked_in: 'accent', in_consultation: 'accent', completed: 'success', cancelled: 'danger',
  ordered: 'info', sample_collected: 'accent', result_uploaded: 'accent', reviewed: 'success',
  pending: 'accent', success: 'success', failed: 'danger', refunded: 'info',
  active: 'success', inactive: 'danger',
};

export default function StatusBadge({ status }) {
  const tone = TONE_MAP[status] || 'info';
  const label = String(status || '').replace(/_/g, ' ');
  return <span className={`badge badge--${tone}`}>{label}</span>;
}
