import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, CalendarClock, Stethoscope, Users as UsersIcon, FlaskConical,
  Pill, ClipboardList, Receipt, UserRound, LogOut, Cross,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import './layout.css';

const NAV_BY_ROLE = {
  patient: [
    { to: '/', label: 'Overview', icon: LayoutDashboard },
    { to: '/doctors', label: 'Find a doctor', icon: Stethoscope },
    { to: '/appointments', label: 'My appointments', icon: CalendarClock },
    { to: '/patient-profile', label: 'My profile', icon: UserRound },
    { to: '/billing', label: 'Billing', icon: Receipt },
  ],
  doctor: [
    { to: '/', label: 'Overview', icon: LayoutDashboard },
    { to: '/appointments', label: 'My appointments', icon: CalendarClock },
    { to: '/patients', label: 'Patients', icon: UsersIcon },
    { to: '/doctor-profile', label: 'My profile & schedule', icon: Stethoscope },
    { to: '/lab-tests', label: 'Lab tests', icon: FlaskConical },
  ],
  nurse: [
    { to: '/', label: 'Overview', icon: LayoutDashboard },
    { to: '/appointment-queue', label: 'Appointment queue', icon: CalendarClock },
    { to: '/patients', label: 'Patients', icon: UsersIcon },
  ],
  receptionist: [
    { to: '/', label: 'Overview', icon: LayoutDashboard },
    { to: '/appointment-queue', label: 'Appointment queue', icon: CalendarClock },
    { to: '/patients', label: 'Patients', icon: UsersIcon },
    { to: '/doctors', label: 'Doctors', icon: Stethoscope },
    { to: '/billing', label: 'Billing', icon: Receipt },
  ],
  lab_technician: [
    { to: '/', label: 'Overview', icon: LayoutDashboard },
    { to: '/lab-tests', label: 'Lab queue', icon: FlaskConical },
  ],
  pharmacist: [
    { to: '/', label: 'Overview', icon: LayoutDashboard },
    { to: '/pharmacy', label: 'Pharmacy', icon: Pill },
    { to: '/prescriptions', label: 'Prescriptions', icon: ClipboardList },
  ],
  admin: [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/appointment-queue', label: 'Appointments', icon: CalendarClock },
    { to: '/patients', label: 'Patients', icon: UsersIcon },
    { to: '/doctors', label: 'Doctors', icon: Stethoscope },
    { to: '/lab-tests', label: 'Lab tests', icon: FlaskConical },
    { to: '/pharmacy', label: 'Pharmacy', icon: Pill },
    { to: '/billing', label: 'Billing', icon: Receipt },
    { to: '/users', label: 'Users', icon: UserRound },
  ],
};

const ROLE_LABEL = {
  patient: 'Patient', doctor: 'Doctor', nurse: 'Nurse', receptionist: 'Receptionist',
  lab_technician: 'Lab Technician', pharmacist: 'Pharmacist', admin: 'Administrator',
};

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const items = NAV_BY_ROLE[user?.role] || [];

  function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <div className="shell">
      <aside className="shell-sidebar">
        <div className="shell-brand">
          <span className="shell-brand-mark"><Cross size={18} /></span>
          <div>
            <div className="shell-brand-name">MediCare+</div>
            <div className="shell-brand-tag">Hospital Management</div>
          </div>
        </div>
        <nav className="shell-nav">
          {items.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) => `shell-nav-item ${isActive ? 'is-active' : ''}`}
            >
              <Icon size={17} strokeWidth={2} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <button type="button" className="shell-logout" onClick={handleLogout}>
          <LogOut size={16} />
          <span>Sign out</span>
        </button>
      </aside>

      <div className="shell-main">
        <header className="shell-topbar">
          <div />
          <div className="shell-user">
            <div className="shell-user-info">
              <span className="shell-user-name">{user?.name}</span>
              <span className="shell-user-role">{ROLE_LABEL[user?.role] || user?.role}</span>
            </div>
            <div className="shell-user-avatar">{user?.name?.[0]?.toUpperCase() || '?'}</div>
          </div>
        </header>
        <main className="shell-content">{children}</main>
      </div>
    </div>
  );
}
