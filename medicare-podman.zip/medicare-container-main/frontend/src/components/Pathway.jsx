import './pathway.css';

const STEPS = [
  { key: 'booked', label: 'Booked' },
  { key: 'checked_in', label: 'Checked in' },
  { key: 'in_consultation', label: 'In consultation' },
  { key: 'completed', label: 'Completed' },
];

export default function Pathway({ status }) {
  if (status === 'cancelled') {
    return (
      <div className="pathway pathway--cancelled">
        <span className="pathway-cancelled-dot" />
        <span>This appointment was cancelled</span>
      </div>
    );
  }

  const currentIndex = STEPS.findIndex((s) => s.key === status);

  return (
    <div className="pathway" role="list" aria-label="Appointment pathway">
      {STEPS.map((step, i) => {
        const state = i < currentIndex ? 'done' : i === currentIndex ? 'active' : 'pending';
        return (
          <div className="pathway-step" data-state={state} key={step.key} role="listitem">
            <div className="pathway-node">
              <span className="pathway-marker">{state === 'done' ? '✓' : i + 1}</span>
            </div>
            <span className="pathway-label">{step.label}</span>
            {i < STEPS.length - 1 && <span className="pathway-connector" data-state={state} />}
          </div>
        );
      })}
    </div>
  );
}
