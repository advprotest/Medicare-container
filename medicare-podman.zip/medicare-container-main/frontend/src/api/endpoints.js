import client from './client';

/* ---------------- Auth ---------------- */
export const authApi = {
  register: (payload) => client.post('/api/auth/register', payload),
  loginJson: (payload) => client.post('/api/auth/login-json', payload),
};

/* ---------------- Users ---------------- */
export const usersApi = {
  me: () => client.get('/api/users/me'),
  list: (role) => client.get('/api/users', { params: role ? { role } : {} }),
  deactivate: (userId) => client.patch(`/api/users/${userId}/deactivate`),
  activate: (userId) => client.patch(`/api/users/${userId}/activate`),
};

/* ---------------- Patients ---------------- */
export const patientsApi = {
  me: () => client.get('/api/patients/me'),
  updateMe: (payload) => client.put('/api/patients/me', payload),
  get: (patientId) => client.get(`/api/patients/${patientId}`),
  list: () => client.get('/api/patients'),
  addMedicalHistory: (patientId, note) =>
    client.post(`/api/patients/${patientId}/medical-history`, null, { params: { note } }),
};

/* ---------------- Doctors ---------------- */
export const doctorsApi = {
  list: (specialization) => client.get('/api/doctors', { params: specialization ? { specialization } : {} }),
  get: (doctorId) => client.get(`/api/doctors/${doctorId}`),
  updateMe: (payload) => client.put('/api/doctors/me', payload),
  setMySchedule: (slots) => client.put('/api/doctors/me/schedule', { slots }),
  getSchedule: (doctorId) => client.get(`/api/doctors/${doctorId}/schedule`),
};

/* ---------------- Appointments ---------------- */
export const appointmentsApi = {
  book: (payload) => client.post('/api/appointments', payload),
  mine: () => client.get('/api/appointments/me'),
  all: (params) => client.get('/api/appointments/all', { params }),
  get: (appointmentId) => client.get(`/api/appointments/${appointmentId}`),
  updateStatus: (appointmentId, status) =>
    client.patch(`/api/appointments/${appointmentId}/status`, { status }),
  reschedule: (appointmentId, payload) =>
    client.patch(`/api/appointments/${appointmentId}/reschedule`, payload),
  addConsultationNotes: (appointmentId, payload) =>
    client.patch(`/api/appointments/${appointmentId}/consultation`, payload),
};

/* ---------------- Lab Tests ---------------- */
export const labTestsApi = {
  order: (payload) => client.post('/api/lab-tests', payload),
  all: (status) => client.get('/api/lab-tests/all', { params: status ? { status } : {} }),
  collectSample: (testId) => client.patch(`/api/lab-tests/${testId}/collect-sample`),
  uploadResult: (testId, payload) => client.patch(`/api/lab-tests/${testId}/upload-result`, payload),
  review: (testId) => client.patch(`/api/lab-tests/${testId}/review`),
  forAppointment: (appointmentId) => client.get(`/api/lab-tests/appointment/${appointmentId}`),
  forPatient: (patientId) => client.get(`/api/lab-tests/patient/${patientId}`),
};

/* ---------------- Prescriptions ---------------- */
export const prescriptionsApi = {
  create: (payload) => client.post('/api/prescriptions', payload),
  forAppointment: (appointmentId) => client.get(`/api/prescriptions/appointment/${appointmentId}`),
  forPatient: (patientId) => client.get(`/api/prescriptions/patient/${patientId}`),
};

/* ---------------- Pharmacy ---------------- */
export const pharmacyApi = {
  add: (payload) => client.post('/api/pharmacy', payload),
  list: (lowStockOnly) => client.get('/api/pharmacy', { params: lowStockOnly ? { low_stock_only: true } : {} }),
  updateStock: (medicineId, quantityDelta) =>
    client.patch(`/api/pharmacy/${medicineId}/stock`, { quantity_delta: quantityDelta }),
};

/* ---------------- Billing ---------------- */
export const billingApi = {
  generate: (payload) => client.post('/api/billing/generate', payload),
  confirm: (payload) => client.post('/api/billing/confirm', payload),
  all: (status) => client.get('/api/billing', { params: status ? { status } : {} }),
  forPatient: (patientId) => client.get(`/api/billing/patient/${patientId}`),
  getInvoice: (invoiceNo) => client.get(`/api/billing/${invoiceNo}`),
};

/* ---------------- Reports ---------------- */
export const reportsApi = {
  dashboard: () => client.get('/api/reports/dashboard'),
  appointmentsTrend: (days) => client.get('/api/reports/appointments-trend', { params: days ? { days } : {} }),
  departmentWisePatients: () => client.get('/api/reports/department-wise-patients'),
  recentAppointments: (limit) => client.get('/api/reports/recent-appointments', { params: limit ? { limit } : {} }),
  recentPayments: (limit) => client.get('/api/reports/recent-payments', { params: limit ? { limit } : {} }),
};