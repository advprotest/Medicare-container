import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';

import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Doctors from './pages/Doctors';
import DoctorPublicProfile from './pages/DoctorPublicProfile';
import DoctorProfile from './pages/DoctorProfile';
import Appointments from './pages/Appointments';
import AppointmentQueue from './pages/AppointmentQueue';
import AppointmentDetail from './pages/AppointmentDetail';
import Patients from './pages/Patients';
import PatientDetail from './pages/PatientDetail';
import PatientProfile from './pages/PatientProfile';
import LabTests from './pages/LabTests';
import Prescriptions from './pages/Prescriptions';
import Pharmacy from './pages/Pharmacy';
import Billing from './pages/Billing';
import Users from './pages/Users';
import NotFound from './pages/NotFound';

function Shell({ roles, children }) {
  return (
    <ProtectedRoute roles={roles}>
      <Layout>{children}</Layout>
    </ProtectedRoute>
  );
}

function PublicOnlyRoute({ children }) {
  const { isAuthenticated } = useAuth();
  if (isAuthenticated) return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<PublicOnlyRoute><Login /></PublicOnlyRoute>} />
      <Route path="/register" element={<PublicOnlyRoute><Register /></PublicOnlyRoute>} />

      <Route path="/" element={<Shell><Dashboard /></Shell>} />

      <Route path="/doctors" element={<Shell><Doctors /></Shell>} />
      <Route path="/doctors/:doctorId" element={<Shell><DoctorPublicProfile /></Shell>} />
      <Route path="/doctor-profile" element={<Shell roles={['doctor']}><DoctorProfile /></Shell>} />

      <Route path="/appointments" element={<Shell roles={['patient', 'doctor']}><Appointments /></Shell>} />
      <Route
        path="/appointment-queue"
        element={<Shell roles={['nurse', 'receptionist', 'admin']}><AppointmentQueue /></Shell>}
      />
      <Route path="/appointments/:appointmentId" element={<Shell><AppointmentDetail /></Shell>} />

      <Route
        path="/patients"
        element={<Shell roles={['doctor', 'nurse', 'receptionist', 'admin']}><Patients /></Shell>}
      />
      <Route
        path="/patients/:patientId"
        element={<Shell roles={['doctor', 'nurse', 'receptionist', 'admin']}><PatientDetail /></Shell>}
      />
      <Route path="/patient-profile" element={<Shell roles={['patient']}><PatientProfile /></Shell>} />

      <Route
        path="/lab-tests"
        element={<Shell roles={['doctor', 'lab_technician', 'admin']}><LabTests /></Shell>}
      />
      <Route
        path="/prescriptions"
        element={<Shell roles={['pharmacist', 'admin']}><Prescriptions /></Shell>}
      />
      <Route
        path="/pharmacy"
        element={<Shell roles={['pharmacist', 'admin', 'doctor', 'nurse', 'receptionist', 'lab_technician']}><Pharmacy /></Shell>}
      />
      <Route
        path="/billing"
        element={<Shell roles={['patient', 'receptionist', 'admin']}><Billing /></Shell>}
      />
      <Route path="/users" element={<Shell roles={['admin']}><Users /></Shell>} />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
