# MediCare+ Frontend

A React (Vite) frontend wired to every endpoint in the MediCare+ FastAPI/MongoDB backend.

## Design

Clinical-records aesthetic: `Newsreader` serif for headers, `IBM Plex Sans` body, `IBM Plex Mono` for
IDs/invoices/timestamps. Deep teal primary, amber accent. The signature element is the **Pathway**
stepper (see `src/components/Pathway.jsx`) — it mirrors the backend's actual appointment state machine
(`booked → checked_in → in_consultation → completed`, with `cancelled` as a branch) on every appointment
detail page.

## Setup

```bash
npm install
cp .env.example .env   # set VITE_API_BASE_URL to your backend URL
npm run dev
```

The backend must be running (see `../medicare-plus/README.md`) with CORS open to the frontend origin —
already configured with `allow_origins=["*"]` in `app/main.py`.

## Roles covered

Every role from the OpenAPI spec has a tailored nav and page set:

- **Patient** — find/book doctors, my appointments, my profile (tabs for profile / medical history /
  lab results / prescriptions), my invoices.
- **Doctor** — appointment queue, patient directory + chart, profile & schedule management, order/review
  lab tests, write consultation notes and prescriptions.
- **Nurse / Receptionist** — appointment queue (check-in, start consultation, cancel), patient directory,
  billing (receptionist: generate invoices, confirm payments).
- **Lab Technician** — lab queue (collect sample → upload result), filterable by status.
- **Pharmacist** — inventory (add medicine, restock/dispense, low-stock filter), prescription lookup.
- **Admin** — everything above, plus the reports dashboard (stat cards, appointments trend line chart,
  department-wise donut chart, recent activity) and user management (activate/deactivate any account).

## Structure

```
src/
  api/            axios client (JWT interceptor) + one function per backend route
  context/        AuthContext (login/register/logout, persisted session)
  components/     Layout shell, Pathway stepper, Modal, StatusBadge, shared CSS
  pages/          one page per feature area, routed by role in App.jsx
```

## Notes

- Two backend endpoints were added to support staff queue views that the original API didn't expose:
  `GET /api/appointments/all` and `GET /api/lab-tests/all` (both role-guarded the same way as their
  sibling endpoints). See `../medicare-plus/app/routers/appointments.py` and `lab_tests.py`.
- This environment has no outbound access to install/run a local MongoDB, so the build was verified via
  `npm run build` (clean) and the backend's own test suite (`pytest`, 7/7 passing) rather than a live
  end-to-end request. Run both servers locally to do a full smoke test.
