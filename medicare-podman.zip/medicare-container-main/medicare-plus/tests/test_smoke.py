"""
Smoke tests for CI (Jenkins 'Test' stage). These don't require a live MongoDB —
they check the app wires up correctly and pure business logic (state machine,
security helpers) behaves as expected. Full integration tests against a real
Mongo instance can be added under tests/integration/ later.
"""
from fastapi.testclient import TestClient
from app.main import app
from app.models.appointment import VALID_TRANSITIONS
from app.core.security import hash_password, verify_password, create_access_token, decode_access_token

client = TestClient(app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "service" in response.json()


def test_password_hashing_roundtrip():
    hashed = hash_password("Secret@123")
    assert hashed != "Secret@123"
    assert verify_password("Secret@123", hashed) is True
    assert verify_password("wrong", hashed) is False


def test_jwt_roundtrip():
    token = create_access_token({"sub": "user123", "role": "patient"})
    payload = decode_access_token(token)
    assert payload["sub"] == "user123"
    assert payload["role"] == "patient"


def test_appointment_state_machine_valid_transitions():
    assert "checked_in" in VALID_TRANSITIONS["booked"]
    assert "cancelled" in VALID_TRANSITIONS["booked"]
    assert "in_consultation" in VALID_TRANSITIONS["checked_in"]
    assert "completed" in VALID_TRANSITIONS["in_consultation"]
    assert VALID_TRANSITIONS["completed"] == []
    assert VALID_TRANSITIONS["cancelled"] == []


def test_appointment_state_machine_no_skipping_steps():
    # Cannot jump straight from booked to completed, skipping consultation
    assert "completed" not in VALID_TRANSITIONS["booked"]
    assert "in_consultation" not in VALID_TRANSITIONS["booked"]


def test_protected_endpoint_requires_auth():
    response = client.get("/api/users/me")
    assert response.status_code == 401
