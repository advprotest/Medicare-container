from datetime import datetime, timezone
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import pharmacy_collection
from app.models.pharmacy import MedicineStockIn, MedicineStockUpdate
from app.models.common import fix_id
from app.core.deps import require_pharmacist, get_current_user

router = APIRouter(prefix="/api/pharmacy", tags=["Pharmacy"])


@router.post("", status_code=201)
async def add_medicine(payload: MedicineStockIn, current_user: dict = Depends(require_pharmacist)):
    """Key Feature: 'Pharmacy & Inventory' management."""
    doc = payload.model_dump()
    doc["updated_at"] = datetime.now(timezone.utc)
    result = await pharmacy_collection.insert_one(doc)
    return fix_id(await pharmacy_collection.find_one({"_id": result.inserted_id}))


@router.get("")
async def list_medicines(low_stock_only: bool = False, current_user: dict = Depends(get_current_user)):
    query = {}
    cursor = pharmacy_collection.find(query)
    items = [fix_id(m) async for m in cursor]
    if low_stock_only:
        items = [m for m in items if m["quantity_in_stock"] <= m["reorder_level"]]
    return items


@router.patch("/{medicine_id}/stock")
async def update_stock(medicine_id: str, payload: MedicineStockUpdate, current_user: dict = Depends(require_pharmacist)):
    """Dispense (negative delta) or restock (positive delta) medicine inventory."""
    medicine = await pharmacy_collection.find_one({"_id": ObjectId(medicine_id)})
    if not medicine:
        raise HTTPException(status_code=404, detail="Medicine not found")

    new_qty = medicine["quantity_in_stock"] + payload.quantity_delta
    if new_qty < 0:
        raise HTTPException(status_code=400, detail="Insufficient stock")

    await pharmacy_collection.update_one(
        {"_id": ObjectId(medicine_id)},
        {"$set": {"quantity_in_stock": new_qty, "updated_at": datetime.now(timezone.utc)}},
    )
    low_stock = new_qty <= medicine["reorder_level"]
    return {"message": "Stock updated", "quantity_in_stock": new_qty, "low_stock_alert": low_stock}
