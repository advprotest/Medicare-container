from datetime import datetime, timedelta, timezone
from app.database import (
    patients_collection, doctors_collection, appointments_collection, payments_collection,
)
from fastapi import APIRouter, Depends
from app.core.deps import require_admin

router = APIRouter(prefix="/api/reports", tags=["Reports & Dashboard"])


@router.get("/dashboard")
async def dashboard_overview(current_user: dict = Depends(require_admin)):
    """
    Matches section 7 'Dashboard Overview (Admin/Hospital)':
    Total Patients, Appointments Today, Total Doctors, Revenue (MTD).
    """
    total_patients = await patients_collection.count_documents({})
    total_doctors = await doctors_collection.count_documents({})

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    appointments_today = await appointments_collection.count_documents({"slot_date": today})

    month_start = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    revenue_cursor = payments_collection.aggregate([
        {"$match": {"status": "success", "created_at": {"$gte": month_start}}},
        {"$group": {"_id": None, "total": {"$sum": "$amount"}}},
    ])
    revenue_result = await revenue_cursor.to_list(length=1)
    revenue_mtd = revenue_result[0]["total"] if revenue_result else 0

    return {
        "total_patients": total_patients,
        "total_doctors": total_doctors,
        "appointments_today": appointments_today,
        "revenue_mtd": revenue_mtd,
    }


@router.get("/appointments-trend")
async def appointments_trend(days: int = 30, current_user: dict = Depends(require_admin)):
    """Section 7 'Appointments Trend' line chart data."""
    start_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")
    cursor = appointments_collection.aggregate([
        {"$match": {"slot_date": {"$gte": start_date}}},
        {"$group": {"_id": "$slot_date", "count": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
    ])
    return [{"date": row["_id"], "appointments": row["count"]} async for row in cursor]


@router.get("/department-wise-patients")
async def department_wise_patients(current_user: dict = Depends(require_admin)):
    """Section 7 'Department Wise Patients' donut chart — appointments grouped by doctor department."""
    cursor = appointments_collection.aggregate([
        {"$lookup": {
            "from": "doctors",
            "let": {"doc_id": {"$toObjectId": "$doctor_id"}},
            "pipeline": [{"$match": {"$expr": {"$eq": ["$_id", "$$doc_id"]}}}],
            "as": "doctor",
        }},
        {"$unwind": "$doctor"},
        {"$group": {"_id": "$doctor.department", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ])
    return [{"department": row["_id"], "count": row["count"]} async for row in cursor]


@router.get("/recent-appointments")
async def recent_appointments(limit: int = 5, current_user: dict = Depends(require_admin)):
    cursor = appointments_collection.find({}).sort("created_at", -1).limit(limit)
    results = []
    async for a in cursor:
        results.append({
            "patient_id": a["patient_id"], "doctor_id": a["doctor_id"],
            "slot_date": a["slot_date"], "slot_time": a["slot_time"], "status": a["status"],
        })
    return results


@router.get("/recent-payments")
async def recent_payments(limit: int = 5, current_user: dict = Depends(require_admin)):
    cursor = payments_collection.find({}).sort("created_at", -1).limit(limit)
    results = []
    async for p in cursor:
        results.append({
            "invoice_no": p["invoice_no"], "amount": p["amount"], "status": p["status"],
        })
    return results
