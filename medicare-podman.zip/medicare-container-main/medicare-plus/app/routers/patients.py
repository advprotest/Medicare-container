from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import patients_collection, users_collection
from app.models.clinical import PatientProfileIn
from app.models.common import fix_id
from app.core.deps import get_current_user, require_doctor, require_staff

router = APIRouter(prefix="/api/patients", tags=["Patients"])


async def _enrich(patient_doc: dict) -> dict:
    user = await users_collection.find_one({"_id": ObjectId(patient_doc["user_id"])})
    doc = fix_id(patient_doc)
    doc["name"] = user["name"]
    doc["email"] = user["email"]
    doc["phone"] = user["phone"]
    return doc


@router.get("/me")
async def get_my_patient_profile(current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "patient":
        raise HTTPException(status_code=403, detail="Only patients have a patient profile")
    profile = await patients_collection.find_one({"user_id": current_user["id"]})
    if not profile:
        raise HTTPException(status_code=404, detail="Patient profile not found")
    return await _enrich(profile)


@router.put("/me")
async def update_my_patient_profile(payload: PatientProfileIn, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "patient":
        raise HTTPException(status_code=403, detail="Only patients can edit their own profile")
    update_data = {k: v for k, v in payload.model_dump().items() if v is not None}
    await patients_collection.update_one({"user_id": current_user["id"]}, {"$set": update_data})
    profile = await patients_collection.find_one({"user_id": current_user["id"]})
    return await _enrich(profile)


@router.get("/{patient_id}")
async def get_patient(patient_id: str, current_user: dict = Depends(require_doctor)):
    """Doctors/admin can view a patient's profile & medical history (Business Flow step 3)."""
    profile = await patients_collection.find_one({"_id": ObjectId(patient_id)})
    if not profile:
        raise HTTPException(status_code=404, detail="Patient not found")
    return await _enrich(profile)


@router.get("")
async def list_patients(current_user: dict = Depends(require_staff)):
    cursor = patients_collection.find({})
    return [await _enrich(p) async for p in cursor]


@router.post("/{patient_id}/medical-history")
async def add_medical_history_note(patient_id: str, note: str, current_user: dict = Depends(require_doctor)):
    """Append a note to the patient's medical history (Key Feature: 'Patient Medical History')."""
    result = await patients_collection.update_one(
        {"_id": ObjectId(patient_id)}, {"$push": {"medical_history": note}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Patient not found")
    return {"message": "Medical history updated"}
