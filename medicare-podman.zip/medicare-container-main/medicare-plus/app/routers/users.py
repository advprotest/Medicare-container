from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import users_collection
from app.models.common import fix_id
from app.core.deps import get_current_user, require_admin

router = APIRouter(prefix="/api/users", tags=["Users"])


def _public(user: dict) -> dict:
    user = fix_id(user)
    user.pop("password_hash", None)
    return user


@router.get("/me")
async def get_my_profile(current_user: dict = Depends(get_current_user)):
    return _public(current_user)


@router.get("")
async def list_users(role: str | None = None, current_user: dict = Depends(require_admin)):
    """Admin-only: Users management page (section 7, Dashboard sidebar 'Users')."""
    query = {"role": role} if role else {}
    cursor = users_collection.find(query)
    return [_public(u) async for u in cursor]


@router.patch("/{user_id}/deactivate")
async def deactivate_user(user_id: str, current_user: dict = Depends(require_admin)):
    result = await users_collection.update_one({"_id": ObjectId(user_id)}, {"$set": {"is_active": False}})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deactivated"}


@router.patch("/{user_id}/activate")
async def activate_user(user_id: str, current_user: dict = Depends(require_admin)):
    result = await users_collection.update_one({"_id": ObjectId(user_id)}, {"$set": {"is_active": True}})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User activated"}
