from datetime import datetime, timezone
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import appointments_collection, doctors_collection, patients_collection, audit_logs_collection
from app.models.appointment import (
    AppointmentCreate, AppointmentStatusUpdate, AppointmentRescheduleIn, ConsultationNotesIn, VALID_TRANSITIONS,
)
from app.models.common import fix_id
from app.core.deps import get_current_user, require_doctor, require_staff
from app.utils.notify import send_notification

router = APIRouter(prefix="/api/appointments", tags=["Appointments"])


@router.post("", status_code=201)
async def book_appointment(payload: AppointmentCreate, current_user: dict = Depends(get_current_user)):
    """Business Flow step 2: 'Appointment Booking' — select doctor, date, time, get confirmation."""
    if current_user["role"] != "patient":
        raise HTTPException(status_code=403, detail="Only patients can book appointments")

    doctor = await doctors_collection.find_one({"_id": ObjectId(payload.doctor_id)})
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")

    # Prevent double-booking the same doctor/date/time slot
    clash = await appointments_collection.find_one({
        "doctor_id": payload.doctor_id,
        "slot_date": payload.slot_date,
        "slot_time": payload.slot_time,
        "status": {"$in": ["booked", "checked_in", "in_consultation"]},
    })
    if clash:
        raise HTTPException(status_code=409, detail="This slot is already booked")

    # Mark the matching slot in the doctor's published schedule as booked (if present)
    await doctors_collection.update_one(
        {"_id": ObjectId(payload.doctor_id), "schedule.slot_date": payload.slot_date,
         "schedule.slot_time": payload.slot_time},
        {"$set": {"schedule.$.is_booked": True}},
    )

    appointment_doc = {
        "patient_id": current_user["id"],
        "doctor_id": payload.doctor_id,
        "slot_date": payload.slot_date,
        "slot_time": payload.slot_time,
        "reason": payload.reason,
        "status": "booked",
        "consultation_notes": None,
        "diagnosis": None,
        "created_at": datetime.now(timezone.utc),
    }
    result = await appointments_collection.insert_one(appointment_doc)
    appointment_id = str(result.inserted_id)

    await send_notification(
        user_id=current_user["id"], channel="email",
        message=f"Your appointment on {payload.slot_date} at {payload.slot_time} is confirmed.",
    )
    await audit_logs_collection.insert_one({
        "action": "APPOINTMENT_BOOKED", "appointment_id": appointment_id,
        "patient_id": current_user["id"], "timestamp": datetime.now(timezone.utc),
    })

    doc = await appointments_collection.find_one({"_id": result.inserted_id})
    return fix_id(doc)


@router.get("/all")
async def list_all_appointments(
    status: str | None = None,
    slot_date: str | None = None,
    current_user: dict = Depends(require_staff),
):
    """Staff/admin queue view across all appointments, optionally filtered."""
    query: dict = {}
    if status:
        query["status"] = status
    if slot_date:
        query["slot_date"] = slot_date
    cursor = appointments_collection.find(query).sort("slot_date", -1)
    return [fix_id(a) async for a in cursor]


@router.get("/me")
async def my_appointments(current_user: dict = Depends(get_current_user)):
    field = "patient_id" if current_user["role"] == "patient" else "doctor_id"
    lookup_id = current_user["id"]
    if current_user["role"] == "doctor":
        from app.database import doctors_collection as dc
        doctor_profile = await dc.find_one({"user_id": current_user["id"]})
        lookup_id = str(doctor_profile["_id"]) if doctor_profile else current_user["id"]
    cursor = appointments_collection.find({field: lookup_id}).sort("slot_date", -1)
    return [fix_id(a) async for a in cursor]


@router.get("/{appointment_id}")
async def get_appointment(appointment_id: str, current_user: dict = Depends(get_current_user)):
    doc = await appointments_collection.find_one({"_id": ObjectId(appointment_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Appointment not found")
    return fix_id(doc)


@router.patch("/{appointment_id}/status")
async def update_status(
    appointment_id: str, payload: AppointmentStatusUpdate, current_user: dict = Depends(require_staff)
):
    """Drives the appointment state machine: booked -> checked_in -> in_consultation -> completed."""
    appt = await appointments_collection.find_one({"_id": ObjectId(appointment_id)})
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    allowed_next = VALID_TRANSITIONS.get(appt["status"], [])
    if payload.status not in allowed_next:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot transition from '{appt['status']}' to '{payload.status}'",
        )

    await appointments_collection.update_one(
        {"_id": ObjectId(appointment_id)}, {"$set": {"status": payload.status}}
    )
    return {"message": f"Appointment status updated to '{payload.status}'"}


@router.patch("/{appointment_id}/reschedule")
async def reschedule_appointment(
    appointment_id: str, payload: AppointmentRescheduleIn, current_user: dict = Depends(require_doctor)
):
    """Let a doctor (or admin) move an already-booked appointment to a new date/time,
    as long as the consultation hasn't started yet."""
    appt = await appointments_collection.find_one({"_id": ObjectId(appointment_id)})
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")
    if appt["status"] not in ("booked", "checked_in"):
        raise HTTPException(status_code=400, detail=f"Cannot reschedule an appointment that is '{appt['status']}'")

    # Prevent clashing with another active appointment for the same doctor/slot
    clash = await appointments_collection.find_one({
        "_id": {"$ne": ObjectId(appointment_id)},
        "doctor_id": appt["doctor_id"],
        "slot_date": payload.slot_date,
        "slot_time": payload.slot_time,
        "status": {"$in": ["booked", "checked_in", "in_consultation"]},
    })
    if clash:
        raise HTTPException(status_code=409, detail="This slot is already booked")

    # Free up the old slot and mark the new one as booked in the doctor's published schedule
    await doctors_collection.update_one(
        {"_id": ObjectId(appt["doctor_id"]), "schedule.slot_date": appt["slot_date"],
         "schedule.slot_time": appt["slot_time"]},
        {"$set": {"schedule.$.is_booked": False}},
    )
    await doctors_collection.update_one(
        {"_id": ObjectId(appt["doctor_id"]), "schedule.slot_date": payload.slot_date,
         "schedule.slot_time": payload.slot_time},
        {"$set": {"schedule.$.is_booked": True}},
    )

    await appointments_collection.update_one(
        {"_id": ObjectId(appointment_id)},
        {"$set": {"slot_date": payload.slot_date, "slot_time": payload.slot_time}},
    )
    await send_notification(
        user_id=appt["patient_id"], channel="email",
        message=f"Your appointment has been rescheduled to {payload.slot_date} at {payload.slot_time}.",
    )
    await audit_logs_collection.insert_one({
        "action": "APPOINTMENT_RESCHEDULED", "appointment_id": appointment_id,
        "by_user_id": current_user["id"], "timestamp": datetime.now(timezone.utc),
    })
    doc = await appointments_collection.find_one({"_id": ObjectId(appointment_id)})
    return fix_id(doc)


@router.patch("/{appointment_id}/consultation")
async def add_consultation_notes(
    appointment_id: str, payload: ConsultationNotesIn, current_user: dict = Depends(require_doctor)
):
    """Business Flow step 3: 'Doctor consultation' — doctor checks history and writes notes."""
    appt = await appointments_collection.find_one({"_id": ObjectId(appointment_id)})
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")
    if appt["status"] not in ("checked_in", "in_consultation"):
        raise HTTPException(status_code=400, detail="Patient must be checked in before consultation notes are added")

    await appointments_collection.update_one(
        {"_id": ObjectId(appointment_id)},
        {"$set": {
            "status": "in_consultation",
            "consultation_notes": payload.notes,
            "diagnosis": payload.diagnosis,
        }},
    )

    history_line = f"{appt['slot_date']}: {payload.diagnosis + ' — ' if payload.diagnosis else ''}{payload.notes}"
    await patients_collection.update_one(
        {"user_id": appt["patient_id"]}, {"$push": {"medical_history": history_line}}
    )

    return {"message": "Consultation notes saved"}