from datetime import datetime, timezone
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import lab_tests_collection, appointments_collection
from app.models.lab import LabTestOrderIn, LabResultUploadIn
from app.models.common import fix_id
from app.core.deps import require_doctor, require_lab_tech, get_current_user
from app.utils.notify import send_notification

router = APIRouter(prefix="/api/lab-tests", tags=["Lab Tests"])


@router.post("", status_code=201)
async def order_lab_test(payload: LabTestOrderIn, current_user: dict = Depends(require_doctor)):
    """Business Flow step 4: 'Tests & Diagnostics (if required)' — doctor orders tests."""
    appt = await appointments_collection.find_one({"_id": ObjectId(payload.appointment_id)})
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    test_doc = {
        "appointment_id": payload.appointment_id,
        "patient_id": appt["patient_id"],
        "doctor_id": appt["doctor_id"],
        "test_name": payload.test_name,
        "notes": payload.notes,
        "status": "ordered",
        "result_summary": None,
        "report_file_url": None,
        "created_at": datetime.now(timezone.utc),
    }
    result = await lab_tests_collection.insert_one(test_doc)
    return fix_id(await lab_tests_collection.find_one({"_id": result.inserted_id}))


@router.get("/all")
async def list_all_lab_tests(
    status: str | None = None,
    current_user: dict = Depends(require_lab_tech),
):
    """Lab technician/admin queue view across all lab tests, optionally filtered by status."""
    query: dict = {"status": status} if status else {}
    cursor = lab_tests_collection.find(query).sort("created_at", -1)
    return [fix_id(t) async for t in cursor]


@router.patch("/{test_id}/collect-sample")
async def collect_sample(test_id: str, current_user: dict = Depends(require_lab_tech)):
    result = await lab_tests_collection.update_one(
        {"_id": ObjectId(test_id), "status": "ordered"}, {"$set": {"status": "sample_collected"}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=400, detail="Test not found or not in 'ordered' status")
    return {"message": "Sample collected"}


@router.patch("/{test_id}/upload-result")
async def upload_result(test_id: str, payload: LabResultUploadIn, current_user: dict = Depends(require_lab_tech)):
    """Business Flow step 5: 'Results uploaded' — lab uploads reports for doctor review."""
    test = await lab_tests_collection.find_one({"_id": ObjectId(test_id)})
    if not test:
        raise HTTPException(status_code=404, detail="Lab test not found")

    await lab_tests_collection.update_one(
        {"_id": ObjectId(test_id)},
        {"$set": {
            "status": "result_uploaded",
            "result_summary": payload.result_summary,
            "report_file_url": payload.report_file_url,
        }},
    )
    await send_notification(
        user_id=test["doctor_id"], channel="email",
        message=f"Lab result uploaded for test '{test['test_name']}'.",
    )
    return {"message": "Result uploaded"}


@router.patch("/{test_id}/review")
async def review_result(test_id: str, current_user: dict = Depends(require_doctor)):
    result = await lab_tests_collection.update_one(
        {"_id": ObjectId(test_id), "status": "result_uploaded"}, {"$set": {"status": "reviewed"}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=400, detail="Test not found or result not yet uploaded")
    return {"message": "Result reviewed by doctor"}


@router.get("/appointment/{appointment_id}")
async def list_tests_for_appointment(appointment_id: str, current_user: dict = Depends(get_current_user)):
    cursor = lab_tests_collection.find({"appointment_id": appointment_id})
    return [fix_id(t) async for t in cursor]


@router.get("/patient/{patient_id}")
async def list_tests_for_patient(patient_id: str, current_user: dict = Depends(get_current_user)):
    """Supports Business Flow step 8: 'Follow-up & reports' — patient views their reports."""
    cursor = lab_tests_collection.find({"patient_id": patient_id})
    return [fix_id(t) async for t in cursor]
