from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import doctors_collection, users_collection
from app.models.clinical import DoctorProfileIn, DoctorScheduleIn
from app.models.common import fix_id
from app.core.deps import get_current_user

router = APIRouter(prefix="/api/doctors", tags=["Doctors"])


async def _enrich(doctor_doc: dict) -> dict:
    user = await users_collection.find_one({"_id": ObjectId(doctor_doc["user_id"])})
    doc = fix_id(doctor_doc)
    doc["name"] = user["name"]
    doc["email"] = user["email"]
    doc["phone"] = user["phone"]
    return doc


@router.get("")
async def list_doctors(specialization: str | None = None):
    """Public listing used for the 'Appointment Booking' step (select doctor, date & time)."""
    query = {"specialization": specialization} if specialization else {}
    cursor = doctors_collection.find(query)
    return [await _enrich(d) async for d in cursor]


@router.get("/{doctor_id}")
async def get_doctor(doctor_id: str):
    doc = await doctors_collection.find_one({"_id": ObjectId(doctor_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Doctor not found")
    return await _enrich(doc)


@router.put("/me")
async def update_my_doctor_profile(payload: DoctorProfileIn, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "doctor":
        raise HTTPException(status_code=403, detail="Only doctors can edit their own profile")
    await doctors_collection.update_one({"user_id": current_user["id"]}, {"$set": payload.model_dump()})
    doc = await doctors_collection.find_one({"user_id": current_user["id"]})
    return await _enrich(doc)


@router.put("/me/schedule")
async def set_my_schedule(payload: DoctorScheduleIn, current_user: dict = Depends(get_current_user)):
    """Key Feature: 'Doctor Schedule Management' — publish available slots for booking."""
    if current_user["role"] != "doctor":
        raise HTTPException(status_code=403, detail="Only doctors can manage their schedule")
    slots = [s.model_dump() for s in payload.slots]
    await doctors_collection.update_one({"user_id": current_user["id"]}, {"$set": {"schedule": slots}})
    return {"message": "Schedule updated", "slot_count": len(slots)}


@router.get("/{doctor_id}/schedule")
async def get_doctor_schedule(doctor_id: str):
    doc = await doctors_collection.find_one({"_id": ObjectId(doctor_id)})
    if not doc:
        raise HTTPException(status_code=404, detail="Doctor not found")
    return {"doctor_id": doctor_id, "slots": doc.get("schedule", [])}
