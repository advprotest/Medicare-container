from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from fastapi import Depends

from app.database import users_collection, patients_collection, doctors_collection, audit_logs_collection
from app.models.user import UserRegister, UserLogin, Token
from app.core.security import hash_password, verify_password, create_access_token

router = APIRouter(prefix="/api/auth", tags=["Auth"])


@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
async def register(payload: UserRegister):
    """Step 1 of Business Flow: 'Patient registers / logs in'. Also used to onboard staff."""
    existing = await users_collection.find_one({"email": payload.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user_doc = {
        "name": payload.name,
        "email": payload.email,
        "phone": payload.phone,
        "password_hash": hash_password(payload.password),
        "role": payload.role,
        "is_active": True,
        "created_at": datetime.now(timezone.utc),
    }
    result = await users_collection.insert_one(user_doc)
    user_id = str(result.inserted_id)

    # Auto-create the linked profile document based on role, matching the DB design
    # (patients / doctors tables in section 6, referenced by user_id)
    if payload.role == "patient":
        await patients_collection.insert_one({
            "user_id": user_id,
            "age": None,
            "gender": None,
            "address": None,
            "blood_group": None,
            "emergency_contact": None,
            "medical_history": [],
            "created_at": datetime.now(timezone.utc),
        })
    elif payload.role == "doctor":
        await doctors_collection.insert_one({
            "user_id": user_id,
            "specialization": "General",
            "experience_years": 0,
            "fees": 0,
            "department": "General",
            "schedule": [],
            "created_at": datetime.now(timezone.utc),
        })

    await audit_logs_collection.insert_one({
        "action": "USER_REGISTERED", "user_id": user_id, "role": payload.role,
        "timestamp": datetime.now(timezone.utc),
    })

    token = create_access_token({"sub": user_id, "role": payload.role})
    return Token(access_token=token, role=payload.role, name=payload.name, user_id=user_id)


@router.post("/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """OAuth2-compatible login (email in 'username' field) for Swagger's Authorize button."""
    user = await users_collection.find_one({"email": form_data.username})
    if not user or not verify_password(form_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="Account is deactivated")

    token = create_access_token({"sub": str(user["_id"]), "role": user["role"]})

    await audit_logs_collection.insert_one({
        "action": "USER_LOGIN", "user_id": str(user["_id"]), "role": user["role"],
        "timestamp": datetime.now(timezone.utc),
    })

    return Token(access_token=token, role=user["role"], name=user["name"], user_id=str(user["_id"]))


@router.post("/login-json", response_model=Token)
async def login_json(payload: UserLogin):
    """Plain JSON login for the React / mobile / kiosk clients (section 2, Client Layer)."""
    user = await users_collection.find_one({"email": payload.email})
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="Account is deactivated")

    token = create_access_token({"sub": str(user["_id"]), "role": user["role"]})
    return Token(access_token=token, role=user["role"], name=user["name"], user_id=str(user["_id"]))
