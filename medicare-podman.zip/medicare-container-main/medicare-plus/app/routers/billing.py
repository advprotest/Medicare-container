from datetime import datetime, timezone
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import payments_collection, appointments_collection, get_next_sequence
from app.models.billing import BillGenerateIn, PaymentConfirmIn
from app.models.common import fix_id
from app.core.deps import require_billing_staff, get_current_user
from app.utils.notify import send_notification

router = APIRouter(prefix="/api/billing", tags=["Billing & Payments"])


@router.post("/generate", status_code=201)
async def generate_bill(payload: BillGenerateIn, current_user: dict = Depends(require_billing_staff)):
    """Business Flow step 7: 'Billing & payment' — generate bill, collect payment (online/offline)."""
    appt = await appointments_collection.find_one({"_id": ObjectId(payload.appointment_id)})
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    invoice_no = await get_next_sequence("invoice_no")
    total_amount = sum(item.amount for item in payload.line_items)

    doc = {
        "invoice_no": invoice_no,
        "patient_id": appt["patient_id"],
        "appointment_id": payload.appointment_id,
        "line_items": [i.model_dump() for i in payload.line_items],
        "amount": total_amount,
        "payment_method": payload.payment_method,
        "status": "pending",
        "gateway_payment_id": None,
        "created_at": datetime.now(timezone.utc),
    }
    result = await payments_collection.insert_one(doc)

    await send_notification(
        user_id=appt["patient_id"], channel="email",
        message=f"Invoice #{invoice_no} generated for INR {total_amount:.2f}.",
    )
    return fix_id(await payments_collection.find_one({"_id": result.inserted_id}))


@router.get("")
async def list_invoices(status: str | None = None, current_user: dict = Depends(require_billing_staff)):
    """Feeds the invoice dropdown on the Billing page — every bill generated shows up here
    until its payment is confirmed, at which point it drops out of the 'pending' view."""
    query = {"status": status} if status else {}
    cursor = payments_collection.find(query).sort("created_at", -1)
    return [fix_id(p) async for p in cursor]


@router.post("/confirm")
async def confirm_payment(payload: PaymentConfirmIn, current_user: dict = Depends(require_billing_staff)):
    """
    Confirms payment success — called after offline cash collection by staff, or after
    the Razorpay/Stripe gateway webhook fires (external integration in the architecture
    diagram; the webhook handler itself is added when the payment gateway is wired up).
    For offline payments, staff records the actual amount collected; for online payments,
    staff records the UPI/GPay transaction reference. The confirmed amount feeds directly
    into the admin dashboard's Revenue (MTD) figure.
    """
    bill = await payments_collection.find_one({"invoice_no": payload.invoice_no})
    if not bill:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if bill["status"] == "success":
        raise HTTPException(status_code=400, detail="Invoice already paid")

    update = {"status": "success", "gateway_payment_id": payload.gateway_payment_id}
    if bill["payment_method"] == "offline" and payload.amount_received is not None:
        update["amount"] = payload.amount_received

    await payments_collection.update_one({"invoice_no": payload.invoice_no}, {"$set": update})
    await send_notification(
        user_id=bill["patient_id"], channel="sms",
        message=f"Payment received for Invoice #{payload.invoice_no}. Thank you.",
    )
    return {"message": "Payment confirmed", "invoice_no": payload.invoice_no}


@router.get("/patient/{patient_id}")
async def list_invoices_for_patient(patient_id: str, current_user: dict = Depends(get_current_user)):
    cursor = payments_collection.find({"patient_id": patient_id}).sort("created_at", -1)
    return [fix_id(p) async for p in cursor]


@router.get("/{invoice_no}")
async def get_invoice(invoice_no: int, current_user: dict = Depends(get_current_user)):
    doc = await payments_collection.find_one({"invoice_no": invoice_no})
    if not doc:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return fix_id(doc)