from datetime import datetime, timezone
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException

from app.database import prescriptions_collection, appointments_collection
from app.models.pharmacy import PrescriptionIn
from app.models.common import fix_id
from app.core.deps import require_doctor, get_current_user

router = APIRouter(prefix="/api/prescriptions", tags=["Prescriptions"])


@router.post("", status_code=201)
async def create_prescription(payload: PrescriptionIn, current_user: dict = Depends(require_doctor)):
    """Business Flow step 6: 'Prescription & treatment' — doctor prescribes medicines."""
    appt = await appointments_collection.find_one({"_id": ObjectId(payload.appointment_id)})
    if not appt:
        raise HTTPException(status_code=404, detail="Appointment not found")

    doc = {
        "appointment_id": payload.appointment_id,
        "patient_id": appt["patient_id"],
        "doctor_id": appt["doctor_id"],
        "medicines": [m.model_dump() for m in payload.medicines],
        "instructions": payload.instructions,
        "created_at": datetime.now(timezone.utc),
    }
    result = await prescriptions_collection.insert_one(doc)
    return fix_id(await prescriptions_collection.find_one({"_id": result.inserted_id}))


@router.get("/appointment/{appointment_id}")
async def get_prescription_for_appointment(appointment_id: str, current_user: dict = Depends(get_current_user)):
    doc = await prescriptions_collection.find_one({"appointment_id": appointment_id})
    if not doc:
        raise HTTPException(status_code=404, detail="No prescription for this appointment")
    return fix_id(doc)


@router.get("/patient/{patient_id}")
async def list_prescriptions_for_patient(patient_id: str, current_user: dict = Depends(get_current_user)):
    cursor = prescriptions_collection.find({"patient_id": patient_id}).sort("created_at", -1)
    return [fix_id(p) async for p in cursor]
