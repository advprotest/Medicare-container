from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel


class PatientProfileIn(BaseModel):
    age: Optional[int] = None
    gender: Optional[Literal["male", "female", "other"]] = None
    address: Optional[str] = None
    blood_group: Optional[str] = None
    emergency_contact: Optional[str] = None


class PatientOut(PatientProfileIn):
    id: str
    user_id: str
    name: str
    email: str
    phone: str
    medical_history: list[str] = []
    created_at: datetime


class DoctorProfileIn(BaseModel):
    specialization: str
    experience_years: Optional[int] = 0
    fees: float
    department: Optional[str] = "General"


class DoctorOut(DoctorProfileIn):
    id: str
    user_id: str
    name: str
    email: str
    phone: str
    created_at: datetime


class DoctorScheduleSlot(BaseModel):
    slot_date: str  # YYYY-MM-DD
    slot_time: str  # HH:MM
    is_booked: bool = False


class DoctorScheduleIn(BaseModel):
    slots: list[DoctorScheduleSlot]
