from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel

PaymentStatus = Literal["pending", "success", "failed", "refunded"]
PaymentMethod = Literal["online", "offline", "insurance"]


class BillLineItem(BaseModel):
    description: str
    amount: float


class BillGenerateIn(BaseModel):
    appointment_id: str
    line_items: list[BillLineItem]
    payment_method: PaymentMethod = "offline"


class PaymentConfirmIn(BaseModel):
    invoice_no: int
    gateway_payment_id: Optional[str] = None  # UPI/GPay reference for online payments
    amount_received: Optional[float] = None  # cash amount collected for offline payments


class PaymentOut(BaseModel):
    id: str
    invoice_no: int
    patient_id: str
    appointment_id: str
    line_items: list[BillLineItem]
    amount: float
    payment_method: PaymentMethod
    status: PaymentStatus
    gateway_payment_id: Optional[str] = None
    created_at: datetime