from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class MedicineItem(BaseModel):
    medicine_name: str
    dosage: str
    frequency: str
    duration: str


class PrescriptionIn(BaseModel):
    appointment_id: str
    medicines: list[MedicineItem]
    instructions: Optional[str] = None


class PrescriptionOut(PrescriptionIn):
    id: str
    patient_id: str
    doctor_id: str
    created_at: datetime


class MedicineStockIn(BaseModel):
    name: str
    category: Optional[str] = None
    unit_price: float
    quantity_in_stock: int
    reorder_level: int = 20


class MedicineStockUpdate(BaseModel):
    quantity_delta: int  # positive to restock, negative to dispense


class MedicineOut(MedicineStockIn):
    id: str
    updated_at: datetime
