from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel

LabTestStatus = Literal["ordered", "sample_collected", "result_uploaded", "reviewed"]


class LabTestOrderIn(BaseModel):
    appointment_id: str
    test_name: str
    notes: Optional[str] = None


class LabResultUploadIn(BaseModel):
    result_summary: str
    report_file_url: Optional[str] = None  # MinIO/S3 reference, per architecture diagram


class LabTestOut(BaseModel):
    id: str
    appointment_id: str
    patient_id: str
    doctor_id: str
    test_name: str
    notes: Optional[str] = None
    status: LabTestStatus
    result_summary: Optional[str] = None
    report_file_url: Optional[str] = None
    created_at: datetime
