from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel

# Appointment state machine (Business Flow, section 1 & 4 of the architecture):
# booked -> checked_in -> in_consultation -> completed
#        \-> cancelled (allowed from booked/checked_in only)
AppointmentStatus = Literal["booked", "checked_in", "in_consultation", "completed", "cancelled"]

VALID_TRANSITIONS: dict[str, list[str]] = {
    "booked": ["checked_in", "cancelled"],
    "checked_in": ["in_consultation", "cancelled"],
    "in_consultation": ["completed"],
    "completed": [],
    "cancelled": [],
}


class AppointmentCreate(BaseModel):
    doctor_id: str
    slot_date: str  # YYYY-MM-DD
    slot_time: str  # HH:MM
    reason: Optional[str] = None


class AppointmentStatusUpdate(BaseModel):
    status: AppointmentStatus


class AppointmentRescheduleIn(BaseModel):
    slot_date: str  # YYYY-MM-DD
    slot_time: str  # HH:MM


class ConsultationNotesIn(BaseModel):
    diagnosis: Optional[str] = None
    notes: str


class AppointmentOut(BaseModel):
    id: str
    patient_id: str
    doctor_id: str
    slot_date: str
    slot_time: str
    reason: Optional[str] = None
    status: AppointmentStatus
    consultation_notes: Optional[str] = None
    diagnosis: Optional[str] = None
    created_at: datetime