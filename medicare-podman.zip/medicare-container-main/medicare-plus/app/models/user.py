from datetime import datetime
from typing import Literal
from pydantic import BaseModel, EmailStr, Field

Role = Literal["patient", "doctor", "nurse", "receptionist", "lab_technician", "pharmacist", "admin"]


class UserRegister(BaseModel):
    name: str
    email: EmailStr
    phone: str
    password: str = Field(min_length=6)
    role: Role = "patient"


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    name: str
    user_id: str


class UserOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    phone: str
    role: Role
    is_active: bool = True
    created_at: datetime
