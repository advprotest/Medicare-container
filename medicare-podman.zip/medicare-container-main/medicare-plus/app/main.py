from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import init_indexes
from app.routers import (
    auth, users, patients, doctors, appointments,
    lab_tests, prescriptions, pharmacy, billing, reports,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_indexes()
    yield


app = FastAPI(
    title=settings.APP_NAME,
    description="Smart Healthcare. Better Management. Better Care. — MongoDB-backed API.",
    version="1.0.0",
    lifespan=lifespan,
)

# Client Layer (Web App / Mobile App / Kiosk) all talk to this single API,
# mirroring the 'API Gateway' box in the architecture diagram.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to specific origins in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(patients.router)
app.include_router(doctors.router)
app.include_router(appointments.router)
app.include_router(lab_tests.router)
app.include_router(prescriptions.router)
app.include_router(pharmacy.router)
app.include_router(billing.router)
app.include_router(reports.router)


@app.get("/", tags=["Health"])
async def root():
    return {"status": "ok", "service": settings.APP_NAME}


@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "healthy"}
