from bson import ObjectId
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

from app.core.security import decode_access_token
from app.database import users_collection

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


async def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_access_token(token)
    if payload is None or "sub" not in payload:
        raise credentials_exception

    user = await users_collection.find_one({"_id": ObjectId(payload["sub"])})
    if user is None:
        raise credentials_exception
    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="Account is deactivated")

    user["id"] = str(user["_id"])
    return user


def require_roles(*allowed_roles: str):
    """Role-based access control guard, per 'Key Features -> Role-based Access Control'."""

    async def role_checker(current_user: dict = Depends(get_current_user)) -> dict:
        if current_user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{current_user['role']}' is not permitted to perform this action",
            )
        return current_user

    return role_checker


# Convenience guards matching the roles in section 1 of the architecture (Patients, Doctors,
# Nurses, Receptionists, Lab Technicians, Pharmacists, Admin)
require_admin = require_roles("admin")
require_doctor = require_roles("doctor", "admin")
require_patient = require_roles("patient", "admin")
require_staff = require_roles("receptionist", "nurse", "admin")
require_lab_tech = require_roles("lab_technician", "admin")
require_pharmacist = require_roles("pharmacist", "admin")
require_billing_staff = require_roles("receptionist", "admin")
