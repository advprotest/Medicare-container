from datetime import datetime, timezone
from app.database import notifications_collection


async def send_notification(user_id: str, channel: str, message: str) -> None:
    """
    Logs a notification and marks it 'queued'. Matches the architecture's
    'Notification Service' + 'SMS / Email Gateway' external integration box.
    Actual SMTP/SMS gateway wiring is added later (kept out per current scope:
    no external/container work until requested).
    """
    await notifications_collection.insert_one({
        "user_id": user_id,
        "channel": channel,  # "sms" | "email" | "push"
        "message": message,
        "status": "queued",
        "created_at": datetime.now(timezone.utc),
    })
