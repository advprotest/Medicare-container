from motor.motor_asyncio import AsyncIOMotorClient
from app.config import settings

client: AsyncIOMotorClient = AsyncIOMotorClient(settings.MONGO_URI)
db = client[settings.MONGO_DB_NAME]

# Collections (mapped from the ER design in the architecture diagram,
# section 6 "Database Design", adapted to MongoDB documents)
users_collection = db["users"]                 # patients, doctors, staff, admin (role field)
patients_collection = db["patients"]            # profile + medical history, linked via user_id
doctors_collection = db["doctors"]              # specialization, schedule slots, linked via user_id
appointments_collection = db["appointments"]     # booking, linked to patient_id/doctor_id
lab_tests_collection = db["lab_tests"]           # tests & diagnostics, linked to appointment_id
prescriptions_collection = db["prescriptions"]   # treatment & prescription, linked to appointment_id
pharmacy_collection = db["pharmacy"]             # medicine inventory
payments_collection = db["payments"]             # billing & payments
notifications_collection = db["notifications"]   # SMS / email / push log
counters_collection = db["counters"]             # atomic auto-increment IDs (invoice/order numbers)
audit_logs_collection = db["audit_logs"]         # role-based audit trail


async def get_next_sequence(name: str) -> int:
    """Atomic auto-increment counter, e.g. for human-readable invoice numbers."""
    result = await counters_collection.find_one_and_update(
        {"_id": name},
        {"$inc": {"seq": 1}},
        upsert=True,
        return_document=True,
    )
    return result["seq"]


async def init_indexes():
    """Create indexes required for the business flow to work correctly and fast."""
    await users_collection.create_index("email", unique=True)
    await users_collection.create_index("role")

    await patients_collection.create_index("user_id", unique=True)
    await doctors_collection.create_index("user_id", unique=True)
    await doctors_collection.create_index("specialization")

    await appointments_collection.create_index([("patient_id", 1)])
    await appointments_collection.create_index([("doctor_id", 1)])
    await appointments_collection.create_index([("doctor_id", 1), ("slot_date", 1), ("slot_time", 1)])
    await appointments_collection.create_index("status")

    await lab_tests_collection.create_index("appointment_id")
    await prescriptions_collection.create_index("appointment_id")

    await payments_collection.create_index("invoice_no", unique=True)
    await payments_collection.create_index("patient_id")

    await pharmacy_collection.create_index("name")
