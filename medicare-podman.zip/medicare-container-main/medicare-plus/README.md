# MediCare+ — Hospital Management System (API)

FastAPI + MongoDB backend implementing the business flow, architecture, and features
from the MediCare+ diagram. Runs in containers with Podman /
podman-compose — see the root `README.md` and `../podman-compose.yml`.

## Stack
- **Python 3.12 / FastAPI** — app layer (stands in for the API Gateway + microservices
  in the diagram; currently a single deployable, structured into per-domain routers
  so it can be split into real microservices later without rewriting logic).
- **MongoDB (Motor, async driver)** — the *only* database, per your instruction. The
  diagram's relational ER tables (users/patients/doctors/appointments/prescriptions/payments)
  are modeled as MongoDB collections with string-ID references instead of foreign keys.
- **JWT (python-jose) + bcrypt (passlib)** — auth & role-based access control.
- **Jenkins** — CI pipeline (lint, compile check, unit tests, artifact packaging).

## Business flow implemented (diagram section 1 & 4)
1. **Patient registers/logs in** → `POST /api/auth/register`, `/api/auth/login`
2. **Appointment booking** (choose doctor, date, time) → `POST /api/appointments`
   (with slot clash protection + doctor schedule sync)
3. **Doctor consultation** (checks history, writes notes) →
   `GET /api/patients/{id}` (history), `PATCH /api/appointments/{id}/consultation`
4. **Tests & diagnostics** (if required) → `POST /api/lab-tests`,
   `PATCH /api/lab-tests/{id}/collect-sample`
5. **Results uploaded** → `PATCH /api/lab-tests/{id}/upload-result`,
   `PATCH /api/lab-tests/{id}/review`
6. **Prescription & treatment** → `POST /api/prescriptions`
7. **Billing & payment** (online/offline) → `POST /api/billing/generate`,
   `POST /api/billing/confirm`
8. **Follow-up & reports** → `GET /api/lab-tests/patient/{id}`,
   `GET /api/prescriptions/patient/{id}`, `GET /api/billing/patient/{id}`

Appointment status is a strict state machine (`app/models/appointment.py`):
`booked → checked_in → in_consultation → completed`, with `cancelled` allowed only
from `booked`/`checked_in`. Illegal transitions (e.g. skipping consultation) are rejected.

## Roles (diagram section 1: Patients, Doctors, Nurses, Receptionists, Lab Technicians,
Pharmacists, Admin) are enforced via `app/core/deps.py` guards on every route.

## MongoDB collections (adapted from section 6 ER design)
`users`, `patients`, `doctors`, `appointments`, `lab_tests`, `prescriptions`,
`pharmacy`, `payments`, `notifications`, `counters` (atomic invoice numbers),
`audit_logs`.

## Dashboard / Reports (diagram section 7)
`GET /api/reports/dashboard` — total patients/doctors, appointments today, revenue MTD
`GET /api/reports/appointments-trend` — line chart data
`GET /api/reports/department-wise-patients` — donut chart data
`GET /api/reports/recent-appointments`, `/api/reports/recent-payments`

## Local setup
```bash
cp .env.example .env          # edit MONGO_URI, JWT_SECRET_KEY
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python seed.py                 # demo admin/doctors/patient/pharmacy stock
uvicorn app.main:app --reload  # http://localhost:8000/docs
```

Demo logins (from `seed.py`): `admin@medicareplus.com` / `Admin@123`,
`dr.smith@medicareplus.com` / `Doctor@123`, `john.doe@example.com` / `Patient@123`.

## CI (Jenkins)
The root `Jenkinsfile` runs: checkout → Python venv (in a Podman container) → flake8 lint →
compile check → pytest (JUnit report) → frontend install/lint/build → artifact archive →
`podman-compose build` → `podman-compose up -d` → health check. See the root `README.md`.

Jenkins credential `medicare-jwt-secret` is optional (defaults to the value in `app/config.py`).

## Not yet built (waiting on your go-ahead)
- OpenShift deployment manifests (section 8)
- React frontend, payment gateway (Razorpay) live integration, SMS/email gateway wiring
  — notification and payment confirmation endpoints exist and log to Mongo (`notifications`,
  `payments` collections) as integration points, ready to plug in real providers.
