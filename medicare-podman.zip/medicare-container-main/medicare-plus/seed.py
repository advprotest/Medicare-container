"""
Seed script: populates demo data for MediCare+ (admin user, sample doctors,
a sample patient, pharmacy stock). Run with: python seed.py
Requires MongoDB reachable at MONGO_URI (see .env).
"""
import asyncio
from datetime import datetime, timezone
from app.database import users_collection, doctors_collection, patients_collection, pharmacy_collection
from app.core.security import hash_password


async def seed():
    print("Seeding MediCare+ demo data...")

    # Admin
    if not await users_collection.find_one({"email": "admin@medicareplus.com"}):
        await users_collection.insert_one({
            "name": "System Admin", "email": "admin@medicareplus.com", "phone": "9999999999",
            "password_hash": hash_password("Admin@123"), "role": "admin", "is_active": True,
            "created_at": datetime.now(timezone.utc),
        })
        print("  Created admin@medicareplus.com / Admin@123")

    # Doctors
    demo_doctors = [
        {"name": "Dr. Smith", "email": "dr.smith@medicareplus.com", "specialization": "Cardiology", "fees": 800, "department": "Cardiology"},
        {"name": "Dr. Brown", "email": "dr.brown@medicareplus.com", "specialization": "Orthopedics", "fees": 700, "department": "Orthopedics"},
        {"name": "Dr. Lee", "email": "dr.lee@medicareplus.com", "specialization": "Neurology", "fees": 900, "department": "Neurology"},
        {"name": "Dr. Patel", "email": "dr.patel@medicareplus.com", "specialization": "General Medicine", "fees": 500, "department": "General"},
    ]
    for d in demo_doctors:
        existing = await users_collection.find_one({"email": d["email"]})
        if existing:
            continue
        result = await users_collection.insert_one({
            "name": d["name"], "email": d["email"], "phone": "9000000000",
            "password_hash": hash_password("Doctor@123"), "role": "doctor", "is_active": True,
            "created_at": datetime.now(timezone.utc),
        })
        await doctors_collection.insert_one({
            "user_id": str(result.inserted_id), "specialization": d["specialization"],
            "experience_years": 8, "fees": d["fees"], "department": d["department"],
            "schedule": [], "created_at": datetime.now(timezone.utc),
        })
        print(f"  Created {d['email']} / Doctor@123")

    # Sample patient
    if not await users_collection.find_one({"email": "john.doe@example.com"}):
        result = await users_collection.insert_one({
            "name": "John Doe", "email": "john.doe@example.com", "phone": "9123456789",
            "password_hash": hash_password("Patient@123"), "role": "patient", "is_active": True,
            "created_at": datetime.now(timezone.utc),
        })
        await patients_collection.insert_one({
            "user_id": str(result.inserted_id), "age": 34, "gender": "male",
            "address": "Chennai, TN", "blood_group": "O+", "emergency_contact": "9988776655",
            "medical_history": [], "created_at": datetime.now(timezone.utc),
        })
        print("  Created john.doe@example.com / Patient@123")

    # Pharmacy stock
    demo_medicines = [
        {"name": "Paracetamol 500mg", "category": "Analgesic", "unit_price": 2.5, "quantity_in_stock": 500, "reorder_level": 50},
        {"name": "Amoxicillin 250mg", "category": "Antibiotic", "unit_price": 6.0, "quantity_in_stock": 200, "reorder_level": 30},
        {"name": "Cetirizine 10mg", "category": "Antihistamine", "unit_price": 1.5, "quantity_in_stock": 300, "reorder_level": 40},
    ]
    for m in demo_medicines:
        if not await pharmacy_collection.find_one({"name": m["name"]}):
            m["updated_at"] = datetime.now(timezone.utc)
            await pharmacy_collection.insert_one(m)
            print(f"  Added stock: {m['name']}")

    print("Seeding complete.")


if __name__ == "__main__":
    asyncio.run(seed())
